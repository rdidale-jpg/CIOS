# MOD Commercial Digital Twin v1.3 — Bounded Release

**Enterprise:** United Kingdom Ministry of Defence and material wider Defence enterprise interfaces  
**Run mode:** Refresh  
**Effective date:** 9 July 2026  
**Public-source cut-off:** 9 July 2026  
**Accepted baseline:** MOD-CDT v1.2 clean release  
**Canonical governed state:** `MOD-CDT-01-Twin-Spine-v1.3.xlsx`

## Release status

This package is the candidate bounded v1.3 release produced under owner authority.

It is decision-ready for the named MOD enterprise-priority, retained-flagship and account-learning decisions described in the Executive Brief and Completion Report. It is not decision-ready for provider-specific pursuit, sponsor outreach, procurement approval or wallet-share inference.

The account-owner decision loop is deferred. `ADEC-MOD-0001` to `ADEC-MOD-0003` remain **Pending**. No Schedule, candidate Redirect, Defer or Reject outcome is inferred.

## Core document set

| ID | File | Purpose |
|---|---|---|
| MOD-CDT-00 | `MOD-CDT-00-Delivery-and-Input-Manifest-v1.3.docx` / `.pdf` | Boundary, inputs, inventory and exclusions |
| MOD-CDT-01 | `MOD-CDT-01-Twin-Spine-v1.3.xlsx` | Canonical governed Twin state |
| MOD-CDT-02 | `MOD-CDT-02-Governed-Commercial-Digital-Twin-v1.3.docx` / `.pdf` | Full governed enterprise publication |
| MOD-CDT-03 | `MOD-CDT-03-Executive-Brief-v1.3.docx` / `.pdf` | Executive decision view |
| MOD-CDT-04 | `MOD-CDT-04-Research-Completion-and-Validation-Report-v1.3.docx` / `.pdf` | Completion, validation, accepted limitations and refresh debt |
| VAL-MOD | `MOD-CDT-v1.3-Release-Validation.json` | Machine-readable artifact, lineage and validation evidence |

## Governed release boundary

The release preserves:

- 24 governed pain, pressure, symptom, driver, mechanism, constraint and Evidence-gap items;
- eight multidimensional selection views;
- 11 broader MOD flagship candidates;
- five technology-industry candidate seams;
- ten public commercial-route views;
- material forecasts, Unknowns and Contradictions;
- zero Provider Fit assessments, zero final provider-specific flagships and zero Pursue recommendations.

One bounded active-acute Burning Platform is retained for Ajax. No enterprise-wide Burning Platform is accepted.

Where operating depth is reconstructed from public evidence, the controlling qualification is:

> Level 3 - outside-in operating hypothesis; internal validation required.

## Accepted limitations

The following remain explicit refresh inputs rather than completed commercial judgements:

1. Account route decisions.
2. Provider Fit.
3. Sponsor access and outreach authority.
4. Provider-specific final flagship selection.
5. Pursue recommendation.
6. Internal mechanism, control, state and outcome evidence where public evidence is insufficient.

Absence of provider/account evidence must not be interpreted as negative Provider Fit, no demand or rejection.

## Recommended reading order

1. Executive Brief.
2. Governed Commercial Digital Twin.
3. Completion and Validation Report.
4. Twin Spine for exact governed state and lineage.
5. Delivery and Input Manifest for release boundary and inventory.

## Refresh triggers

Refresh this release when any of the following occurs:

- an attributable `ARS/ARE` return or authorised `ADEC` change set;
- a material route, framework, sponsor, SRO or decision-right change;
- a security or information-sharing boundary change;
- a material programme, award, workshare or incumbent-position change;
- the NAO MOD affordability assessment expected in Autumn 2026;
- the no-response review on 31 August 2026;
- any material source, formula, artifact or contradiction change.

## Acceptance

The package remains candidate intelligence until the acceptance authority records final owner acceptance of the delivered package for the named decisions and accepted limitations.
