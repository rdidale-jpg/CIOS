Banking Explorer interactive demonstration — commit abb87dba2d1e2300f1679833f0b8bad36fbacbd7

On your Mac: extract the entire ZIP, keep all files together, and open index.html with Safari.
Walkthrough: Banking Explorer -> Lloyds Banking Group -> Explore operating landscape -> Customer & service -> inspect insight -> Inspect source context -> browser Back -> Banking breadcrumb.
Use a narrow browser window or responsive mode for the mobile layout.

This is a static interactive HTML export, not a hosted application or a running FLORA backend. It contains approved public fixtures and conceptual diagrams. No sign-in, write operations or production connection is available. Links outside the demonstration open preview-information.html.

If your browser blocks local-file navigation, run this command from the extracted folder:
  python3 -m http.server 8767 --bind 127.0.0.1
Then open http://127.0.0.1:8767/index.html in Safari on that same Mac.

The 43-page export was verified in Chromium over a local static server: desktop/mobile navigation, SVG links, insight disclosures, evidence drill-down and return; no external requests, scripts or forms. Direct file URLs are blocked by the managed workspace browser policy; Safari itself was not available for verification. No external preview service was deployed.
