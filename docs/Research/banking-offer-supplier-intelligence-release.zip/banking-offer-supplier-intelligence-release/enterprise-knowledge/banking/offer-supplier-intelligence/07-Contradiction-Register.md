# Contradiction Register

**Asset ID:** `EK-BANK-OSI-001-CON`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19

| Contradiction ID | Proposition in tension | Commercial consequence | Supporting / conflicting evidence | Treatment |
|---|---|---|---|---|
| BK-OSI-CON-001 | Supplier partnership versus accessible whitespace | A participant can show strong offer fit while a major incumbent supplier already publicly occupies the same domain. | Offer fit may be real but commercially inaccessible without a complementary seam. | NatWest AWS/Accenture; Lloyds Google Cloud; Nationwide Accenture/Form3/Broadcom; Barclays Microsoft. | Do not convert fit into pursuit; preserve as Shape/Validate evidence need. |
| BK-OSI-CON-002 | Customer-facing AI momentum versus trust/control risk | Starling and Barclays show visible AI adoption, while Banking mechanisms preserve conduct, trust, operational resilience and fraud-control constraints. | Supports Secure AI Governance but weakens any generic autonomous-AI positioning. | WEB-012; WEB-013; BK-SRC-MECH; BK-SRC-OBS. | Offer must be governed and outcome-evidenced. |
| BK-OSI-CON-003 | Cloud modernisation as opportunity versus cloud concentration as risk | Cloud is an enabler for AI/data, but CTP designation turns cloud dependency into regulated resilience risk. | Hybrid Cloud and Cloud Modernisation fit must include resilience and exit optionality. | WEB-005; BK-SRC-INFRA; WEB-001; WEB-003; WEB-008. | Treat cloud offers as regulated operating model, not pure migration. |
| BK-OSI-CON-004 | Digital challenger fit versus in-house platform strength | Monzo and Starling fit data/AI themes, but their commercial position includes strong in-house digital/platform capability. | Generic transformation offers may be less suitable even when the mechanism is relevant. | BK-SRC-CP; WEB-009; WEB-011; WEB-012. | Use industry variant or specialist assurance/additive roles. |
| BK-OSI-CON-005 | Mutual access differentiation versus efficiency pressure | Nationwide’s member/access posture supports Customer Operations Transformation but may resist branch-reduction framing. | Offer positioning must avoid incumbent cost-takeout assumptions. | BK-SRC-CP; BK-SRC-MPI; WEB-006; WEB-008. | Frame as member-value/service sustainability where evidence supports. |
| BK-OSI-CON-006 | Supplier-authored evidence versus independent delivery proof | Several supplier-footprint sources are supplier-authored and may overstate benefits. | Confidence in relationship can be high while confidence in realised outcome remains medium or low. | WEB-004; WEB-007; WEB-008; WEB-011. | Separate relationship visibility from proof of benefit. |
