# Evidence Register

**Asset ID:** `EK-BANK-OSI-001-EVID`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19

## Governed Banking and Method sources

| Source ID | Source | Use in this release |
|---|---|---|
| BK-SRC-IND-TWIN | Banking Industry Twin v1.0 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-MECH | Banking Mechanism Catalogue EK-BANK-MECH-CAT-001 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-OBS | Banking Observation Register EK-BANK-OBS-REG-001 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-RHYP | Banking Reinvention Hypotheses EK-BANK-RHYP-001 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-MPI | Banking Market Participant Intelligence EK-BANK-MPI-001 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-CP | Banking Commercial Position Profiles EK-BANK-CP-001 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-INFRA | UK Banking Payments Infrastructure Twin v0.1 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-MATRIX | Four-Bank Mechanism Differential Matrix v2.1 | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-EGM | EGM-001 Enterprise Growth Method | Governing Banking, offer-method or commercial-domain input. |
| BK-SRC-ROB | CDTPD-005 Rob Commercial Domain Profile | Governing Banking, offer-method or commercial-domain input. |

## Public supplier and partnership evidence

| Source ID | Source | Evidence use | Source type | Limitation |
|---|---|---|---|---|
| WEB-001 | Lloyds Banking Group, 'Lloyds Banking Group accelerates AI innovation with Google Cloud', 9 Apr 2025, https://www.lloydsbankinggroup.com/media/press-releases/2025/lloyds-banking-group-2025/lloyds-banking-group-accelerates-ai-innovation-with-google-cloud.html | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-002 | Google Cloud customer case study: Lloyds Banking Group, https://cloud.google.com/customers/lloydsbankinggroup | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-003 | NatWest Group, 'NatWest Group to Accelerate bank-wide data and AI transformation', 23 Jul 2025, https://www.natwestgroup.com/news-and-insights/news-room/press-releases/ai-and-data/2025/jul/natwest-group-to-accelerate-bank-wide-data-and-ai-transformation.html | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-004 | Accenture newsroom, NatWest Group five-year collaboration with Accenture and AWS, 23 Jul 2025, https://newsroom.accenture.com/news/2025/natwest-group-to-accelerate-bank-wide-data-and-ai-transformation-through-5-year-collaboration-with-accenture-and-aws | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-005 | HM Treasury, 'UK financial system strengthened with new safeguards for major technology providers', July 2026, https://www.gov.uk/government/news/uk-financial-system-strengthened-with-new-safeguards-for-major-technology-providers | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-006 | Nationwide Building Society, 'Nationwide partners with Form3 to underpin future payment strategy', 2021, https://www.nationwide.co.uk/media/news/nationwide-partners-with-form3-to-underpin-future-payment-strategy | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-007 | Accenture newsroom, 'Nationwide Building Society to Modernize its Digital Payments System in the Cloud with Accenture and Form3', 6 Mar 2023, https://newsroom.accenture.com/news/2023/nationwide-building-society-to-modernize-its-digital-payments-system-in-the-cloud-with-accenture-and-form3 | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-008 | Broadcom, 'Broadcom and Nationwide Deepen Strategic Partnership to Power Group-Wide Private Cloud Transformation', 24 Jun 2026, https://news.broadcom.com/releases/broadcom-nationwide-private-cloud-transformation | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-009 | Google Cloud customer case study: Monzo Bank, https://cloud.google.com/customers/monzo-bank | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-010 | Monzo, 'An introduction to Monzo's data stack', 14 Oct 2021, https://monzo.com/blog/2021/10/14/an-introduction-to-monzos-data-stack | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-011 | Google Cloud customer case study: Starling, https://cloud.google.com/customers/starling | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-012 | Starling, 'Starling launches UK’s first Agentic AI financial assistant', 2026, https://www.starlingbank.com/news/starling-launches-agentic-ai-assistant/ | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-013 | Microsoft, 'Barclays to roll out Microsoft 365 Copilot to 100,000 colleagues', 9 Jun 2025, https://ukstories.microsoft.com/features/barclays-rolls-out-microsoft-365-copilot-to-100000-colleagues/ | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-014 | Barclays, 'Scaling AI at Barclays', 2025, https://home.barclays/insights/2025/07/scaling-AI-at-Barclays/ | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-015 | Barclays, 'Barclays joins forces with Microsoft and NVIDIA to launch new Innovation Hub', 9 Jun 2025, https://home.barclays/news/press-releases/2025/06/barclays-joins-forces-with-microsoft-and-nvidia-to-launch-new-in/ | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |
| WEB-016 | Santander UK, 'Santander UK completes cash acquisition of TSB Banking Group', 1 May 2026, https://www.santander.co.uk/about-santander/media-centre/press-releases/santander-uk-completes-cash-acquisition-of-tsb-banking | Supplier footprint / current partnership / regulatory context. | Public web source | Public source; supports visible relationship or ecosystem fact but not full contract scope, workshare or realised benefits. |

## Evidence discipline

- Supplier-authored evidence is useful for relationship visibility but not treated as independent proof of benefits.
- Bank-authored partnership announcements are useful for current strategic direction but not complete supplier wallet-share evidence.
- Regulatory designation evidence supports ecosystem criticality but not bank-specific consumption.
- Existing Banking Enterprise Knowledge remains the primary interpretation boundary.
