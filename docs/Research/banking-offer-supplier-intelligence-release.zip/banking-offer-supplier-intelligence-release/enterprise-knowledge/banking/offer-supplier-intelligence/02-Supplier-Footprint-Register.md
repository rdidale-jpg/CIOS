# Supplier Footprint Register

**Asset ID:** `EK-BANK-OSI-001-SUP`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19  
**Purpose:** Preserve visible supplier relationships without treating public partnership as proof of full delivery or realised benefits.

## Evidence-state vocabulary

| State | Meaning |
|---|---|
| Current delivery / public partnership | Recent public evidence indicates an active relationship or delivery collaboration. |
| Historic relationship | Evidence exists but may not prove current activity. |
| Public partnership | Relationship is public but delivery status may be unclear. |
| Marketing case study | Supplier or platform case study; useful but not independent proof of benefit. |
| Inferred presence | Not accepted as fact in this release unless explicitly labelled. |
| Human knowledge | Not used in this release; capture through template only. |

## Supplier records

| Supplier record | Participant | Supplier / ecosystem actor | Evidence state | Delivery area | Capability / technology | Likely executive context | Evidence | Confidence | Unknowns |
|---|---|---|---|---|---|---|---|---|---|
| BK-SUP-001 | BK-MP-001 | Lloyds Banking Group | Google Cloud | Current delivery / public partnership | AI, ML, data science platform; Vertex AI / Agent Platform | AI and data platform; mortgage income verification example; customer and colleague AI capability | CIO/CTO, CDAO, customer/colleague experience leaders | WEB-001; WEB-002; BK-SRC-MPI; BK-SRC-CP | High | Does not prove exclusive cloud position, broader supplier stack or total workshare. |
| BK-SUP-002 | BK-MP-002 | NatWest Group | AWS + Accenture | Current five-year collaboration / public partnership | Bank-wide data, analytics and AI transformation | Customer data platform, personalisation, fraud alert acceleration, operations simplification | CEO/COO/CIO/CDO/CRO roles inferred from scope | WEB-003; WEB-004; BK-SRC-MPI; BK-SRC-CP | High | Commercial terms, internal owner model, subcontractors and delivery split unknown. |
| BK-SUP-003 | BK-MP-003 | Barclays | Microsoft | Current partnership / product rollout | Microsoft 365 Copilot rollout to 100,000 colleagues | Colleague AI, productivity, enterprise AI adoption interface | CIO/CTO, COO, HR/workforce transformation, business-unit leaders | WEB-013; BK-SRC-MPI; BK-SRC-CP | High | Does not prove broader Azure platform dependency or benefits realisation. |
| BK-SUP-004 | BK-MP-003 | Barclays | Microsoft + NVIDIA | Ecosystem partnership / innovation hub | AI and deep-tech Innovation Hub in London | Ecosystem/startup orchestration, AI innovation, partner access | Strategy, Innovation, Technology, Investment Bank / Eagle Labs roles as applicable | WEB-015; BK-SRC-MPI; BK-SRC-CP | Medium | Innovation hub participation does not prove core banking transformation delivery. |
| BK-SUP-005 | BK-MP-005 | Nationwide / Virgin Money | Form3 | Current/historic public partnership | Cloud-native payments platform | Future payments strategy; payments processing modernisation | COO/CIO/Payments leadership | WEB-006; WEB-007; BK-SRC-MPI; BK-SRC-CP | High | Current rollout status, inherited Virgin Money integration and operational steady-state unknown. |
| BK-SUP-006 | BK-MP-005 | Nationwide / Virgin Money | Accenture | Public partnership / systems integrator role | Digital payments transformation with Form3 | Migration/adoption of cloud-native payments platform | COO/CIO/Transformation leadership | WEB-007; BK-SRC-MPI; BK-SRC-CP | High | Current delivery status and broader integration role unknown. |
| BK-SUP-007 | BK-MP-005 | Nationwide / Virgin Money | Broadcom / VMware | Current strategic partnership | Private cloud / hybrid cloud services and VMware Cloud Foundation | Group-wide technology transformation and hybrid cloud strategy | CIO/CTO/Infrastructure, COO, operational resilience stakeholders | WEB-008 | High | Public source is supplier-authored; consumer-side benefits and architecture details require validation. |
| BK-SUP-008 | BK-MP-006 | Monzo | Google Cloud | Case study / long-standing platform relationship | BigQuery, Looker, data stack | Customer insight, business performance analytics, data-driven product model | Data, product, engineering leadership | WEB-009; WEB-010; BK-SRC-MPI; BK-SRC-CP | High | Other primary cloud, core and resilience arrangements not fully proven here. |
| BK-SUP-009 | BK-MP-007 | Starling | Google Cloud | Case study / current AI evidence | AI/ML and customer-facing AI environment | AI money tools, fraud/scam intelligence, customer guidance; support to Engine proposition | CIO/CTO, Product, Customer, Risk roles | WEB-011; WEB-012; BK-SRC-MPI; BK-SRC-CP | High | Exact split between Starling-built capability and Google services requires validation. |
| BK-SUP-010 | BK-MP-008 | Pay.UK / UK retail payments infrastructure | Pay.UK ecosystem providers and participant banks | Infrastructure operator / ecosystem dependency | Bacs, Faster Payments, ICS, Confirmation of Payee, Request to Pay; access rules and standards | Retail payments reachability and overlay services | Payments, operations, risk, resilience stakeholders across banks | BK-SRC-INFRA; BK-SRC-MPI | High | Underlying technology vendors, procurement state and delivery company model are not fully evidenced here. |
| BK-SUP-011 | BK-MP-009 | Critical third-party cloud and AI providers | AWS, Google Cloud, Microsoft, Oracle | Regulatory designation / ecosystem participant | Systemic technology services to UK financial services | Cloud/AI infrastructure dependency and operational-resilience oversight | CIO/CTO, CRO, COO, regulators | WEB-005; BK-SRC-INFRA; BK-SRC-CP | High | Designation does not identify each bank’s consumption or workload criticality. |
| BK-SUP-012 | BK-MP-004 | Santander UK | Banco Santander group platforms / internal ecosystem | Parent-led internal platform relationship | ONE Transformation, Gravity, Openbank/PagoNxt capability context; TSB integration dependency | Global platform convergence and UK ring-fenced transformation | CEO/CIO/COO/Integration leadership | BK-SRC-MPI; BK-SRC-CP; WEB-016 | Medium | Named external suppliers for TSB integration, UK cloud, data and AI are not sufficiently evidenced in this release. |

## Supplier footprint interpretation

The strongest visible supplier footprints are concentrated in data/AI/cloud and payments modernisation:

- Lloyds — Google Cloud AI/data platform evidence.
- NatWest — AWS and Accenture data/AI transformation evidence.
- Barclays — Microsoft colleague AI and Microsoft/NVIDIA ecosystem innovation evidence.
- Nationwide / Virgin Money — Form3, Accenture and Broadcom/VMware payments and hybrid/private cloud evidence.
- Monzo — Google Cloud data platform evidence.
- Starling — Google Cloud AI evidence.
- Santander UK — stronger evidence for parent-led platform convergence and TSB integration than for named external suppliers.
- Pay.UK — infrastructure control is visible, but underlying supplier model remains incomplete.
- CTP cloud providers — important ecosystem actors and potential partners/competitors, not ordinary Banking prospects.
