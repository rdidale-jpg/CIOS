# Unknown Register

**Asset ID:** `EK-BANK-OSI-001-UNK`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19

| Unknown ID | Unknown | Why it matters | Evidence required | Priority |
|---|---|---|---|---|
| BK-OSI-UNK-001 | Provider capability proof | No governed internal evidence was supplied proving the organisation has delivered each initial offer in Banking. | Constrains answer to 'what can we credibly sell' because market fit is not the same as provider fit. | Provider case studies, delivery references, capability statements, assurance-approved proof points. | High |
| BK-OSI-UNK-002 | Incumbent supplier workshare | Public supplier evidence rarely reveals share of wallet, role split or whether supplier relationship is active delivery or case-study reuse. | Constrains competitive strategy and offer entry points. | Contract notices, procurement records, human-supplied account knowledge, supplier award evidence. | High |
| BK-OSI-UNK-003 | Executive ownership | Most public evidence does not identify the accountable executive role for specific transformation seams. | Constrains executive conversation sequencing. | Leadership announcements, programme governance, human knowledge, annual report responsibility mapping. | High |
| BK-OSI-UNK-004 | Benefits realisation | Supplier announcements and bank press releases rarely prove operational benefit realisation. | Constrains strength of supplier footprint and competitor-performance interpretation. | Post-implementation reports, KPI movement, regulatory/customer outcome evidence. | High |
| BK-OSI-UNK-005 | Santander UK external supplier footprint | Santander UK has clear group-platform and TSB integration pressure, but named UK external suppliers were not sufficiently evidenced in this release. | Limits offer-fit precision for Santander UK. | TSB integration awards, procurement evidence, partner announcements, human account knowledge. | High |
| BK-OSI-UNK-006 | Pay.UK delivery company and vendor model | Infrastructure Twin identifies payment infrastructure dependency, but not all underlying vendors or future procurement operating model. | Limits supplier whitespace and offer fit for infrastructure participant. | Pay.UK/Bank of England procurement and delivery-model publications. | High |
| BK-OSI-UNK-007 | Offer limitations by bank archetype | The provided offer labels are high-level; detailed scope, exclusions, pricing, delivery model and regulated-industry proof were not supplied. | Prevents stronger fit judgement beyond qualitative alignment. | Offer playbooks, delivery accelerators, regulated-banking references, provider-fit overlay. | High |
| BK-OSI-UNK-008 | Human knowledge not yet captured | No human-supplied knowledge was provided for incumbents, relationships, sales experience, competitive intelligence or internal capability. | Leaves access, account politics and provider fit unresolved. | Human Knowledge Capture Template completion. | High |
