# Offer Fit Matrix

**Asset ID:** `EK-BANK-OSI-001-FIT`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19  
**Method:** Qualitative fit only. No numerical scoring. Fit is not a sales recommendation.

## Fit states

- **Strong fit** — repeated evidence supports natural alignment between participant position, mechanisms, observations and offer.
- **Conditional fit** — offer may fit, but supplier occupancy, ownership, proof, timing or operating model requires validation.
- **Industry variant required** — generic offer is insufficient; Banking-specific or participant-specific adaptation required.
- **Custom solution required** — visible need exists but supplied offer labels do not fit cleanly.
- **Not currently suitable** — current evidence does not support fit.
- **Insufficient evidence** — evidence is not enough to classify.

## Participant-offer fit matrix

| Participant ID | Participant | Strong fit | Strong-fit offers | Conditional / variant fit | Other relevant offers | Why | Main Unknowns | Lineage |
|---|---|---|---|---|---|---|---|---|
| BK-MP-001 | Lloyds Banking Group | Strong fit | BK-OFFER-003; BK-OFFER-004; BK-OFFER-005 | Conditional fit | BK-OFFER-001; BK-OFFER-002; BK-OFFER-006; BK-OFFER-007; BK-OFFER-008 | Scale optimiser position, Google Cloud AI evidence, simplification and legacy/cloud pressure. | Must validate incumbent suppliers, internal delivery control and whether executive need is already owned by Google/in-house teams. | BK-CP-001; BM-01; BM-06; BM-07; BM-16; BM-17; BM-20; BM-21; BRH-007; BRH-008; BRH-009 |
| BK-MP-002 | NatWest Group | Strong fit | BK-OFFER-005; BK-OFFER-006; BK-OFFER-007; BK-OFFER-008 | Conditional fit | BK-OFFER-001; BK-OFFER-002; BK-OFFER-003; BK-OFFER-004 | AWS/Accenture data and AI collaboration directly supports data foundations, customer operations and controlled AI themes. | Five-year collaboration may reduce near-term access for overlapping offers unless complementary seams exist. | BK-CP-002; BM-03; BM-05; BM-11; BM-14; BM-20; BM-21; BRH-004; BRH-006; BRH-007 |
| BK-MP-003 | Barclays | Strong fit | BK-OFFER-006; BK-OFFER-005 | Conditional fit | BK-OFFER-002; BK-OFFER-003; BK-OFFER-004; BK-OFFER-007 | Universal-bank complexity, colleague AI rollout and Innovation Hub point to governed AI and data foundations; IB scope increases risk/control relevance. | Large-bank internal and Microsoft/NVIDIA ecosystem may already occupy AI innovation pathways. | BK-CP-003; BM-10; BM-13; BM-16; BM-20; BM-21; BM-22; BRH-007; BRH-012; BRH-014 |
| BK-MP-004 | Santander UK | Conditional fit | BK-OFFER-003; BK-OFFER-004; BK-OFFER-005; BK-OFFER-007 | Industry variant required | BK-OFFER-001; BK-OFFER-002; BK-OFFER-006; BK-OFFER-008 | TSB integration and group-platform convergence create cloud/data/operations fit, but parent-led platform control may limit external role. | External supplier footprint weak; global Santander internal technology may dominate opportunity boundary. | BK-CP-004; BM-16; BM-17; BM-18; BM-20; BM-21; BRH-008; BRH-011 |
| BK-MP-005 | Nationwide / Virgin Money | Strong fit | BK-OFFER-003; BK-OFFER-004; BK-OFFER-008 | Conditional fit | BK-OFFER-001; BK-OFFER-005; BK-OFFER-006; BK-OFFER-007 | Mutual trust/member-value position, branch commitment, Virgin integration, payments/cloud partnerships and hybrid cloud evidence support customer operations, cloud and access-model offers. | Existing Accenture/Form3/Broadcom footprint may constrain supplier entry and redirect fit toward assurance, integration, operating model or adoption seams. | BK-CP-005; BM-02; BM-04; BM-06; BM-08; BM-10; BM-16; BM-17; BM-22; BRH-003; BRH-011; BRH-013 |
| BK-MP-006 | Monzo | Strong fit | BK-OFFER-005 | Industry variant required | BK-OFFER-001; BK-OFFER-006; BK-OFFER-007; BK-OFFER-008 | Digital challenger and data-driven model make data/AI foundations relevant, but cloud-native in-house capabilities mean external fit must be specialist, not generic transformation. | May be inappropriate for broad cloud modernisation or incumbent-style customer operations unless growth, resilience or vulnerable-customer evidence strengthens. | BK-CP-006; BM-01; BM-03; BM-06; BM-09; BM-11; BM-21; BRH-001; BRH-002; BRH-010 |
| BK-MP-007 | Starling | Strong fit | BK-OFFER-001; BK-OFFER-006 | Industry variant required | BK-OFFER-005; BK-OFFER-007 | Starling has visible customer-facing AI and Google Cloud environment; financial-crime control history supports secure governance relevance. | Engine and in-house platform strengths may make generic cloud/data transformation unsuitable; partner role would need be narrow and additive. | BK-CP-007; BM-03; BM-05; BM-11; BM-12; BM-20; BM-21; BRH-006; BRH-007; BRH-010 |
| BK-MP-008 | Pay.UK / UK retail payments infrastructure | Conditional fit | BK-OFFER-003; BK-OFFER-006; BK-OFFER-007 | Not currently suitable | BK-OFFER-001; BK-OFFER-008 | Infrastructure participant fit is around resilience, governed change, ecosystem operations and assurance, not bank customer propositions. | Supplier/procurement model and delivery company operating model require validation before commercial fit can be assessed. | BK-CP-008; BM-13; BM-15; BM-18; BM-22; BRH-005; BRH-006 |
| BK-MP-009 | Critical third-party cloud and AI providers | Partner/competitor fit | BK-OFFER-003; BK-OFFER-004; BK-OFFER-005; BK-OFFER-006 | Not a normal bank-customer fit | BK-OFFER-001; BK-OFFER-008 | Cloud and AI providers are ecosystem participants, likely partners or competitors rather than targets for Banking offers. | Runtime should not treat them as normal banking prospects without a separate provider-market model. | BK-CP-009; BM-18; BM-20; BM-21; BRH-008; BRH-007 |

## Offer interpretation by participant

### Lloyds Banking Group

Commercial position: scale optimiser with strong deposit/current-account, hedge and simplification logic. Existing offers fit best where they strengthen the AI/data/cloud simplification pathway and preserve customer trust. The most natural executive conversation is not generic AI; it is whether AI, data and cloud can improve cost, customer and control outcomes without weakening scale trust.

### NatWest Group

Commercial position: relationship-bank variant with visible customer-data and AI transformation activity. Data & AI Foundations, Secure AI Governance and Customer Operations Transformation align naturally, but AWS/Accenture already occupy a major part of the visible transformation space.

### Barclays

Commercial position: universal bank and capital-markets participant. Offer fit is strongest around governed AI, data foundations and workforce/colleague AI adoption because enterprise complexity, conduct and capital-market controls make generic productivity narratives insufficient.

### Santander UK

Commercial position: UK ring-fenced expression of global Santander platform strategy. Fit depends on whether external providers can complement group-led platform convergence and TSB integration rather than competing with internal group capabilities.

### Nationwide / Virgin Money

Commercial position: mutual/member-value participant integrating a bank acquisition while defending branch/access trust. Customer Operations Transformation and Hybrid Cloud fit strongly where framed around member value, integration resilience and service sustainability.

### Monzo

Commercial position: digital-native primary-bank challenger. Data & AI Foundations fit naturally, but broad cloud modernisation or incumbent-style operations offers are weaker unless tied to growth, resilience, fraud, vulnerable-customer support or regulatory maturity.

### Starling

Commercial position: profitable digital bank plus banking-platform operator. Customer Experience Agentic AI and Secure AI Governance fit the visible AI trajectory, but generic platform transformation is weak because Starling’s own platform capability is a strategic strength.

### Pay.UK / UK retail payments infrastructure

Commercial position: infrastructure control layer. Offers fit only where translated into resilience, ecosystem operations, governance and change assurance; bank-customer CX offers do not transfer directly.

### Critical third-party cloud and AI providers

Commercial position: ecosystem participants, partners and competitors. They should be modelled as supplier/partner actors, not normal Banking customers for this offer matrix.
