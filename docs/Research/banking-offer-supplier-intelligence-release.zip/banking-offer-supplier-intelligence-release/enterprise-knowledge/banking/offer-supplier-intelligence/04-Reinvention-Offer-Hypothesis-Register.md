# Reinvention Offer Hypothesis Register

**Asset ID:** `EK-BANK-OSI-001-ROH`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19  
**Purpose:** Identify repeated unmet commercial needs that may require a new Reinvention Offer. These are hypotheses, not recommendations or products.

## Governance

A Reinvention Offer Hypothesis must be repeated across participant types and trace to observations, mechanisms, Commercial Positions, participant intelligence and supplier footprint evidence. It must remain falsifiable.

---

## BK-ROH-001 — Governed Banking AI Trust Layer

| Field | State |
|---|---|
| Repeated customer problem | Multiple participants are scaling AI into customer, colleague, fraud and operating workflows, but the recurring unmet need is governed evidence of safe adoption rather than another AI point solution. |
| Why existing offers only partially solve it | Existing offers partially cover AI, data and governance, but none alone resolves conduct, model-risk, customer-outcome, third-party and operational-resilience evidence across the AI lifecycle. |
| Participant types sharing the problem | Large incumbents, universal banks, mutuals and digital challengers; visible in Lloyds, NatWest, Barclays, Starling and CTP context. |
| Executives likely to own it | CRO, CIO/CTO, CDAO, COO, Chief Customer Officer, Board Risk Committee. |
| Suppliers currently visible / dominant | Google Cloud, AWS, Microsoft, Accenture, NVIDIA and internal bank AI teams dominate visible supply. |
| Whitespace | Whitespace exists if a provider can connect AI governance, adoption, outcome evidence and service-control operations into a Banking-specific offer. |
| Supporting evidence | WEB-001; WEB-003; WEB-005; WEB-011; WEB-012; WEB-013; BK-SRC-OBS; BK-SRC-RHYP |
| Contradicting evidence | AI adoption may already be owned by hyperscaler/SI collaborations at some banks; in-house challengers may not need external governance except assurance. |
| Confidence | High |
| Unknowns | Actual buyer budget, existing model-risk tooling and regulatory expectations at each participant. |
| Monitoring indicators | New public AI governance controls, regulatory statements, supplier awards, benefits evidence, customer outcome metrics, resilience events and participant-specific procurements. |
| Status | Candidate Reinvention Offer Hypothesis; do not treat as an approved offer. |

---

## BK-ROH-002 — Shared Banking Experience and Assisted-Access Orchestration

| Field | State |
|---|---|
| Repeated customer problem | Access-model change is visible across incumbent, mutual and challenger variants, but customer need spans digital, assisted, branch, hub and payment/cash infrastructure. |
| Why existing offers only partially solve it | Customer Experience Agentic AI and Customer Operations Transformation cover parts of this, but not necessarily the shared-infrastructure, physical/assisted access and conduct evidence layer. |
| Participant types sharing the problem | Lloyds, Nationwide/Virgin, Monzo, Starling and Pay.UK/LINK/Post Office-access ecosystem where supported by evidence. |
| Executives likely to own it | Chief Customer Officer, Distribution leader, COO, Retail Banking Director, Conduct/Risk roles. |
| Suppliers currently visible / dominant | Banks, Post Office/LINK ecosystem, Pay.UK overlays, contact-centre vendors and in-house channel teams. |
| Whitespace | Whitespace is a Banking-specific operating model that makes assisted access measurable and interoperable rather than treating it as branch replacement. |
| Supporting evidence | BK-SRC-OBS; BK-SRC-MPI; BK-SRC-CP; BK-SRC-INFRA |
| Contradicting evidence | Nationwide may treat access as differentiation rather than gap; digital challengers may rely on partnerships instead of owning assisted access. |
| Confidence | Medium |
| Unknowns | Current assisted-access suppliers, participant-specific vulnerable-customer evidence and customer outcome measures. |
| Monitoring indicators | New public AI governance controls, regulatory statements, supplier awards, benefits evidence, customer outcome metrics, resilience events and participant-specific procurements. |
| Status | Candidate Reinvention Offer Hypothesis; do not treat as an approved offer. |

---

## BK-ROH-003 — Customer Outcome Evidence Engine

| Field | State |
|---|---|
| Repeated customer problem | Consumer Duty, trust, complaints, fraud and digital migration require banks to prove outcomes across channels, but many transformation assets focus on delivery rather than outcome evidence. |
| Why existing offers only partially solve it | Current offers touch customer operations, data foundations and secure AI governance; none explicitly owns cross-channel outcome evidence as a reusable Banking offer. |
| Participant types sharing the problem | All bank types; especially incumbents/mutuals with branch migration and challengers with primary-bank conversion ambitions. |
| Executives likely to own it | Chief Customer Officer, CRO, COO, Retail Banking Director, Data leader. |
| Suppliers currently visible / dominant | CRM/contact-centre vendors, data platforms, risk/compliance tools, analytics providers, consultancies. |
| Whitespace | Whitespace exists where outcome evidence can be tied to mechanisms BM-02, BM-04, BM-11, BM-14 and BM-22. |
| Supporting evidence | BK-SRC-OBS; BK-SRC-MECH; BK-SRC-RHYP; BK-SRC-CP |
| Contradicting evidence | Some banks may already possess internal conduct MI; public evidence rarely reveals outcome instrumentation maturity. |
| Confidence | High |
| Unknowns | Internal conduct MI, complaints journey data, quality assurance tooling and regulator feedback. |
| Monitoring indicators | New public AI governance controls, regulatory statements, supplier awards, benefits evidence, customer outcome metrics, resilience events and participant-specific procurements. |
| Status | Candidate Reinvention Offer Hypothesis; do not treat as an approved offer. |

---

## BK-ROH-004 — Cloud Resilience and Exit-Optionality for Banking

| Field | State |
|---|---|
| Repeated customer problem | CTP designation makes cloud dependency a systemic banking concern, while banks are simultaneously moving AI/data/platform workloads into hyperscaler ecosystems. |
| Why existing offers only partially solve it | Hybrid Cloud and Cloud Modernisation cover platform work, but not necessarily third-party concentration, exit/stand-in, resilience evidence and regulatory assurance as one Banking-specific offer. |
| Participant types sharing the problem | Incumbents, universal banks, mutuals, challengers and infrastructure participants; especially where hyperscaler dependency is visible. |
| Executives likely to own it | CIO/CTO, CRO, COO, Operational Resilience, Supplier/Procurement leaders. |
| Suppliers currently visible / dominant | AWS, Google Cloud, Microsoft, Oracle, Broadcom/VMware, Accenture and in-house engineering teams. |
| Whitespace | Whitespace exists if the offer packages workload placement, exit planning, resilience evidence, supplier governance and AI platform dependency management. |
| Supporting evidence | WEB-005; WEB-008; WEB-009; WEB-011; BK-SRC-INFRA; BK-SRC-RHYP |
| Contradicting evidence | Hyperscalers themselves may provide assurance tooling; regulators may define standardised requirements that reduce advisory whitespace. |
| Confidence | High |
| Unknowns | Bank-specific critical service mappings, exit plan quality and provider contract rights. |
| Monitoring indicators | New public AI governance controls, regulatory statements, supplier awards, benefits evidence, customer outcome metrics, resilience events and participant-specific procurements. |
| Status | Candidate Reinvention Offer Hypothesis; do not treat as an approved offer. |

---

## BK-ROH-005 — Fraud-Friction Operating Model

| Field | State |
|---|---|
| Repeated customer problem | APP fraud, scam detection, onboarding/KYC and payment friction recur across banking participants and infrastructure, but solutions risk shifting friction rather than reducing it. |
| Why existing offers only partially solve it | AI-first Operations, Intelligent Operations and Secure AI Governance each cover part of this, but not the end-to-end fraud/friction operating model across payments, customer experience and liability. |
| Participant types sharing the problem | All banks and payments infrastructure; especially challengers and high digital engagement banks. |
| Executives likely to own it | CRO, COO, Chief Customer Officer, Payments/Fraud leaders. |
| Suppliers currently visible / dominant | Google Cloud, AWS, bank in-house fraud teams, payment infrastructure operators, specialist fraud vendors. |
| Whitespace | Whitespace exists for an offer that balances friction, liability, vulnerable-customer treatment, AI detection, Confirmation of Payee and service design. |
| Supporting evidence | WEB-012; BK-SRC-INFRA; BK-SRC-OBS; BK-SRC-MECH; BK-SRC-RHYP |
| Contradicting evidence | Some participants may already have advanced in-house fraud AI; public evidence may overstate product launches versus realised fraud reduction. |
| Confidence | Medium |
| Unknowns | Fraud-loss outcomes, false-positive rates, complaints, operational volumes and model governance evidence. |
| Monitoring indicators | New public AI governance controls, regulatory statements, supplier awards, benefits evidence, customer outcome metrics, resilience events and participant-specific procurements. |
| Status | Candidate Reinvention Offer Hypothesis; do not treat as an approved offer. |

---

## BK-ROH-006 — Banking Reinvention Control Tower

| Field | State |
|---|---|
| Repeated customer problem | Multiple banks are running simplification, cloud, AI, data, integration and acquisition programmes, but repeated Unknowns concern benefits, supplier split, executive ownership and outcome evidence. |
| Why existing offers only partially solve it | Existing offers cover delivery components; the gap is not another PMO but a governed reinvention intelligence/control layer across evidence, mechanisms, suppliers, outcomes and learning. |
| Participant types sharing the problem | Incumbents, Santander/TSB integration, Nationwide/Virgin integration, Barclays universal-bank complexity and infrastructure change. |
| Executives likely to own it | CEO/COO/CFO/CIO/Transformation Director/Board Change Committee. |
| Suppliers currently visible / dominant | SIs, consultancies, PMO/PPM vendors, internal transformation offices. |
| Whitespace | Whitespace exists if the offer is positioned as evidence-backed enterprise control and learning, not generic programme reporting. |
| Supporting evidence | BK-SRC-MPI; BK-SRC-CP; BK-SRC-OBS; BK-SRC-RHYP; BK-SRC-EGM |
| Contradicting evidence | Could duplicate existing transformation-partner or SI governance unless differentiated by observation/mechanism lineage and learning model. |
| Confidence | Medium |
| Unknowns | Actual transformation office maturity, tooling, benefits baselines and current SI roles. |
| Monitoring indicators | New public AI governance controls, regulatory statements, supplier awards, benefits evidence, customer outcome metrics, resilience events and participant-specific procurements. |
| Status | Candidate Reinvention Offer Hypothesis; do not treat as an approved offer. |

