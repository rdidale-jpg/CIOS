# Provider Offer Catalogue

**Asset ID:** `EK-BANK-OSI-001-OFFER`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19  
**Purpose:** Model supplied Provider Offer labels as governed commercial knowledge. This is not marketing copy.

## Governance note

The initial offer names were supplied in the commission. No provider-specific proof pack was supplied. Therefore this release distinguishes:

- **Market-fit evidence** — Banking evidence shows the problem exists.
- **Provider-fit evidence** — proof that the organisation can deliver the offer. This remains Unknown unless supplied.
- **Commercial accessibility** — whether a participant has space for the offer despite incumbent suppliers. This is not assumed.

## Offer objects

---

## BK-OFFER-001 — Customer Experience Agentic AI

```yaml
offer: "Customer Experience Agentic AI"
problem: "Banks need to serve customers through app, contact-centre, branch, assisted and fraud journeys without increasing friction, complaints or conduct risk."
business_outcomes: "Improved customer guidance, faster resolution, proactive insight, reduced avoidable contact, better vulnerable-customer triage where governed safely."
executive_buyers: "Chief Customer Officer; Retail Banking Director; COO; CIO/CTO; CRO where conduct/fraud risk is material."
operating_model_change: "Introduces AI-assisted or agentic journeys into customer operations, requiring human escalation, model governance, data access, service controls and customer-outcome evidence."
technology_dependencies: "Identity, consent, event data, CRM/contact centre, knowledge management, audit logs, AI/model operations, controls, integration with servicing channels."
enterprise_conditions: "Relevant where digital engagement, service pressure, fraud/scams, complaints or assisted-access pressure are visible. Inappropriate where customer data, controls, escalation or service accountability are immature."
industry_relevance: "Strong banking relevance through BM-01, BM-02, BM-03, BM-04, BM-11, BM-14, BM-21, BM-22 and hypotheses BRH-001, BRH-006, BRH-007, BRH-014."
proof: "Market need is evidenced by Banking observations and participant moves; provider-specific delivery proof was not supplied in this commission."
limitations: "Do not position as autonomous banking decisioning without conduct, model-risk, explainability and human accountability evidence."
commercial_differentiators: "Differentiates if connected to outcome evidence, risk controls and channel orchestration rather than chatbot deployment."
known_competitors: "Google Cloud, Microsoft, AWS, Accenture, incumbent platform vendors and bank in-house AI teams are visible competitor/partner classes."
confidence: "Medium"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

Customer Experience Agentic AI is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

---

## BK-OFFER-002 — AI-first Operations

```yaml
offer: "AI-first Operations"
problem: "Banks face cost, resilience, fraud, regulatory and service pressures that cannot be solved only by front-end digital migration."
business_outcomes: "Productivity, faster exception handling, more consistent controls, reduced manual work, improved operational resilience evidence."
executive_buyers: "COO; CIO/CTO; Transformation Director; CRO; Operations Director."
operating_model_change: "Re-architects operational workflows around AI-assisted work, decision support, exception routing and learning loops."
technology_dependencies: "Workflow platforms, process mining, data quality, AI governance, integration, controls, auditability, service management."
enterprise_conditions: "Relevant where simplification, legacy operations, fraud operations or operational resilience pressure is visible. Inappropriate where process ownership and controls are unclear."
industry_relevance: "Strong relevance through BM-09, BM-11, BM-12, BM-13, BM-17, BM-18, BM-19, BM-20, BM-21 and BRH-006, BRH-007, BRH-009, BRH-014."
proof: "Banking assets evidence repeated simplification, AI and operations pressure; provider-specific proof not supplied."
limitations: "Cannot credibly be sold as pure automation if the bank’s problem is trust, inclusion, customer outcomes or regulatory assurance."
commercial_differentiators: "Stronger where presented as controlled operating-model redesign rather than headcount reduction."
known_competitors: "Accenture, AWS, Microsoft, Google Cloud, service-management vendors, BPO/MSP incumbents and bank internal automation teams."
confidence: "Medium"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

AI-first Operations is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

---

## BK-OFFER-003 — Hybrid Cloud

```yaml
offer: "Hybrid Cloud"
problem: "Banks need cloud agility but remain constrained by resilience, regulatory oversight, legacy estates, data location, exit planning and critical-third-party dependency."
business_outcomes: "Resilient hybrid architecture, workload placement discipline, migration optionality, better cloud governance and CTP control."
executive_buyers: "CIO; CTO; COO; CRO; Head of Infrastructure; Operational Resilience lead."
operating_model_change: "Changes platform operations, risk oversight, workload governance, vendor management and service-continuity assurance."
technology_dependencies: "Hybrid platforms, private cloud, public cloud, observability, data controls, IAM, networking, FinOps, exit/runbook capability."
enterprise_conditions: "Relevant where legacy estates, cloud concentration, CTP oversight or migration sequencing appear material. Inappropriate where a bank is fully digital-native and the challenge is product growth rather than platform migration."
industry_relevance: "Strong relevance through BM-13, BM-16, BM-17, BM-18, BM-20 and BRH-008."
proof: "Public evidence shows cloud dependency, regulatory CTP designation and participant-specific cloud partnerships; provider-specific delivery proof not supplied."
limitations: "Avoid implying cloud migration solves operating-model or data-quality issues without the adjacent change work."
commercial_differentiators: "Differentiates if it combines resilience, regulation, exit planning and transformation economics."
known_competitors: "AWS, Google Cloud, Microsoft, Oracle, Broadcom/VMware, Accenture, bank infrastructure incumbents."
confidence: "High"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

Hybrid Cloud is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

---

## BK-OFFER-004 — Cloud Modernisation

```yaml
offer: "Cloud Modernisation"
problem: "Legacy banking estates constrain speed, resilience, data/AI adoption and operating-cost reduction."
business_outcomes: "Application migration, platform simplification, decommissioning support, improved developer productivity and service reliability."
executive_buyers: "CIO; CTO; Transformation Director; COO; CFO where cost takeout is material."
operating_model_change: "Requires portfolio rationalisation, migration factory discipline, service transition, supplier coordination and business ownership of decommissioning."
technology_dependencies: "Cloud landing zones, data migration, integration, DevSecOps, containers, APIs, testing, cutover and resilience patterns."
enterprise_conditions: "Relevant for incumbents, integration programmes and banks with visible simplification or platform renewal. Less relevant where the participant already owns a cloud-native architecture and wants product/market extension."
industry_relevance: "Relevant through BM-16, BM-17, BM-18, BM-19, BM-20, BM-21 and BRH-008, BRH-009, BRH-011."
proof: "Market evidence includes Lloyds/Google Cloud, NatWest/AWS/Accenture, Nationwide/Form3/Accenture/Broadcom and Starling/Google Cloud signals."
limitations: "Modernisation is insufficient if it ignores customer, conduct, data and operating-model consequences."
commercial_differentiators: "Differentiates where positioned as migration-to-business-outcome traceability."
known_competitors: "Cloud hyperscalers, Accenture, Form3, Broadcom/VMware, core banking vendors, SI incumbents."
confidence: "High"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

Cloud Modernisation is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

---

## BK-OFFER-005 — Data & AI Foundations

```yaml
offer: "Data & AI Foundations"
problem: "Banking AI, fraud, personalisation, credit, conduct and operational insight depend on accessible, governed, high-quality data."
business_outcomes: "Better data access, AI readiness, reusable data products, model governance, faster experimentation, outcome measurement."
executive_buyers: "Chief Data Officer; CIO/CTO; COO; CRO; Chief Customer Officer."
operating_model_change: "Creates data product ownership, governance, lineage, AI enablement, access controls and measurement discipline."
technology_dependencies: "Data platforms, lakehouse/warehouse, metadata, lineage, data quality, MLOps, feature stores, governance, analytics tooling."
enterprise_conditions: "Relevant wherever banks publicly evidence customer data, AI transformation, fraud data, migration or relationship-data ambitions. Inappropriate where executive need is only channel estate or branch economics without data linkage."
industry_relevance: "Strong relevance through BM-01, BM-03, BM-05, BM-09, BM-11, BM-14, BM-19, BM-20, BM-21 and BRH-001, BRH-004, BRH-006, BRH-007, BRH-014."
proof: "Strong market-fit evidence from Lloyds/Google Cloud, NatWest/AWS/Accenture, Monzo/Google Cloud and Starling/Google Cloud."
limitations: "Foundation work can be over-positioned unless linked to named outcomes and accountable business mechanisms."
commercial_differentiators: "Differentiates by tying data foundations to banking mechanisms and executive outcomes rather than abstract platform work."
known_competitors: "Google Cloud, AWS, Microsoft, Accenture, in-house data engineering teams, analytics vendors."
confidence: "High"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

Data & AI Foundations is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

---

## BK-OFFER-006 — Secure AI Governance

```yaml
offer: "Secure AI Governance"
problem: "Banks need to scale AI while preserving conduct, explainability, operational resilience, model risk, customer trust and third-party control."
business_outcomes: "Safer AI adoption, auditable controls, policy-to-run governance, third-party oversight, reduced regulatory and reputational risk."
executive_buyers: "CRO; CIO/CTO; Chief Data/AI Officer; COO; Legal/Compliance; Board Risk Committee stakeholders."
operating_model_change: "Creates governance boards, policies, controls, model inventory, AI risk workflows, evidence capture and assurance routines."
technology_dependencies: "Model registry, monitoring, policy controls, lineage, testing, access control, secure environments, vendor risk tooling."
enterprise_conditions: "Relevant where AI is customer-facing, fraud-facing, decision-supporting or dependent on critical technology providers. Inappropriate as a standalone compliance exercise disconnected from adoption."
industry_relevance: "Strong relevance through BM-02, BM-11, BM-12, BM-13, BM-18, BM-20, BM-21 and BRH-006, BRH-007, BRH-014."
proof: "CTP regulation, Starling customer-facing AI, Lloyds and NatWest AI platform moves and Barclays large colleague AI rollout support market relevance."
limitations: "Governance without implementation pathways may be seen as friction rather than enablement."
commercial_differentiators: "Differentiates where governance accelerates safe adoption rather than blocking innovation."
known_competitors: "Cloud vendors, advisory firms, risk consultancies, model-risk vendors, in-house risk teams."
confidence: "High"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

Secure AI Governance is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

---

## BK-OFFER-007 — Intelligent Operations

```yaml
offer: "Intelligent Operations"
problem: "Bank operations need to sense, route, resolve and learn across fraud, onboarding, servicing, resilience and back-office workflows."
business_outcomes: "Operational visibility, exception reduction, control consistency, service resilience and productivity."
executive_buyers: "COO; Operations Director; CIO; CRO; Customer Operations leader."
operating_model_change: "Turns operational work into measurable, AI-assisted flows with escalation, control and learning loops."
technology_dependencies: "Process/workflow orchestration, AI agents, knowledge, service management, observability, analytics, integration, controls."
enterprise_conditions: "Relevant where operational cost, manual work, fraud friction or multi-channel service complexity are visible. Inappropriate where data/control foundations are insufficient."
industry_relevance: "Relevant through BM-11, BM-12, BM-13, BM-17, BM-18, BM-21, BM-22 and BRH-006, BRH-007, BRH-014."
proof: "Repeated operations, simplification, fraud and resilience pressures are evident across Banking assets; provider-specific proof not supplied."
limitations: "Should not be confused with generic BPO unless enduring run accountability is part of scope."
commercial_differentiators: "Differentiates by combining operations, AI, controls and outcome evidence."
known_competitors: "BPO/MSP providers, Accenture, ServiceNow/CRM/workflow vendors, in-house operations transformation teams."
confidence: "Medium"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

Intelligent Operations is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

---

## BK-OFFER-008 — Customer Operations Transformation

```yaml
offer: "Customer Operations Transformation"
problem: "Banks must support customers across digital, contact-centre, branch, assisted, vulnerable-customer and complaint journeys under conduct and cost pressure."
business_outcomes: "Improved service effectiveness, channel coordination, complaint reduction, assisted-access support, better customer outcomes."
executive_buyers: "Chief Customer Officer; COO; Retail Banking Director; Distribution leader; Conduct/Risk stakeholders."
operating_model_change: "Redesigns customer journeys, channel handoffs, workforce roles, operating measures, escalation and outcome evidence."
technology_dependencies: "CRM, contact centre, knowledge management, digital service, branch tooling, analytics, workforce management, AI-assisted guidance."
enterprise_conditions: "Relevant where access-model change, complaints, service quality, digital migration or vulnerable-customer pressure is visible. Inappropriate if positioned only as contact-centre technology without conduct and channel model change."
industry_relevance: "Strong relevance through BM-02, BM-03, BM-04, BM-11, BM-14, BM-15, BM-22 and BRH-001, BRH-003, BRH-014."
proof: "Banking observations and commercial position profiles show repeated access, trust and customer-outcome pressure; provider-specific proof not supplied."
limitations: "Needs bank-specific treatment: mutual, incumbent and challenger versions differ materially."
commercial_differentiators: "Differentiates through participant-specific access and trust logic rather than generic CX."
known_competitors: "Customer-service platforms, contact-centre vendors, Accenture, cloud AI vendors, bank in-house channel teams."
confidence: "High"
unknowns: "Provider-specific proof, pricing, delivery model, regulated Banking references and partner ecosystem evidence remain incomplete unless supplied separately."
```

### Commercial interpretation

Customer Operations Transformation is commercially relevant when the Banking mechanism and Commercial Position evidence align with the participant's current pressure. It should not be treated as universally sellable across all banks.

