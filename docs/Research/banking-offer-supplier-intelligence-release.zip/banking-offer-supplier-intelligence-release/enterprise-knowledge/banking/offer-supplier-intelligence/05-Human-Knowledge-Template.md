# Human Knowledge Template

**Asset ID:** `EK-BANK-OSI-001-HK`  
**Parent asset:** `EK-BANK-OSI-001`  
**Effective date:** 2026-07-19  
**Purpose:** Capture human-supplied commercial intelligence without merging it silently with public evidence.

## Capture rules

Every item must be labelled **Human supplied** and must record contributor, date, confidence and corroboration requirement. Human knowledge can improve commercial judgement but does not become public evidence.

## Template

```yaml
human_knowledge_id:
knowledge_type: 
  - known_incumbent
  - executive_relationship
  - programme_insight
  - sales_experience
  - competitive_intelligence
  - customer_feedback
  - internal_delivery_capability
  - provider_reference
participant_id:
participant_name:
related_offer_id:
related_supplier_id:
related_mechanism_ids:
related_observation_ids:
statement:
source_person:
contributor_role:
date_supplied:
direct_knowledge_or_interpretation:
confidence:
commercial_relevance:
what_it_supports:
what_it_does_not_support:
corroboration_required:
evidence_to_seek:
privacy_or_confidentiality_constraints:
usable_in_flora_runtime:
  - safe_summary
  - restricted_summary
  - not_runtime_safe
review_owner:
review_date:
status:
  - candidate
  - accepted_human_knowledge
  - superseded
  - contradicted
  - retired
```

## Initial state

No human-supplied knowledge was used in this release. All supplier footprints and offer-fit interpretations are based on governed Banking assets and public evidence listed in the Evidence Register.
