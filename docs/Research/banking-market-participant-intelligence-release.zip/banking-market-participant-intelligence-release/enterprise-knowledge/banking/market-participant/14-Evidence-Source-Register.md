# Evidence Source Register

**Asset ID:** `EK-BANK-MPI-001-SRC`  
**Effective date:** 2026-07-19  
**Source boundary:** Governed Banking assets only. No new external research used.

| Source ID | Governed asset | Role in this build | Limitation |
|---|---|---|---|
| `BRIEF-001` | Pasted markdown.md — Build Governed Banking Market Participant Intelligence | Commission authority, scope, outputs and acceptance criteria | Commission instruction; not industry evidence |
| `BANK-FOUND-001` | Banking Industry Foundation | Participant taxonomy, industry boundary, source families and ecosystem participants | Foundation-level; not full participant twin |
| `BANK-TWIN-001` | Banking Industry Twin v1.0 | Synthesis source for participant variants, tensions, scope and current model | Canonical view but not a participant-specific register |
| `BANK-MECH-001` | Banking Mechanism Catalogue | Canonical BM-01 to BM-22 cross-reference authority | Mechanisms, not observations or participant moves |
| `BANK-OBS-001` | Banking Observation Register | Canonical BK-OBS-001 to BK-OBS-050 observation cross-reference authority | Existing observations only; new participant observations are candidate additions |
| `BANK-RHYP-001` | Banking Reinvention Hypotheses v0.1 | BRH-001 to BRH-014 opportunity/hypothesis reference set | Hypotheses are learning objects, not predictions or recommendations |
| `BANK-INFRA-001` | UK Banking Payments Infrastructure Twin v0.1 | Infrastructure participant, control-boundary and shared-rail evidence | Public infrastructure evidence; not a bank enterprise twin |
| `BANK-MATRIX-001` | Four-Bank Mechanism Differential Matrix v2.1 | Corrected BM identifier discipline and mechanism confidence boundary | Matrix covers selected participants; not exhaustive |
| `ENT-LBG-001` | Lloyds Banking Group Enterprise Twin + Deepening | Scale incumbent participant evidence | Public evidence boundary; salary/direct-debit primacy remains unknown |
| `ENT-NTW-002` | NatWest Group Enterprise Twin | Commercial incumbent and AI relationship-bank variant evidence | Public evidence boundary; route/procurement detail incomplete |
| `ENT-NWVM-003` | Nationwide / Virgin Money Enterprise Twin | Mutual/member-value, branch trust and integration evidence | Realised Virgin Money integration benefits remain uncertain |
| `ENT-MONZO-004` | Monzo Bank Enterprise Twin | Consumer challenger primary-conversion and growth-control evidence | Public primacy metric is active-user based, not all registered customers |
| `ENT-STAR-005` | Starling Bank Enterprise Twin | SME-weighted challenger and platform-export evidence | Exact Engine/platform commercial economics not fully visible |
| `ENT-BARC-006` | Barclays Enterprise Twin | Universal-bank portfolio and capital-markets candidate evidence | Investment-bank mechanism set remains candidate, not canonical |
| `ENT-SAN-007` | Santander UK Enterprise Twin | Multinational platform-bank subsidiary and TSB integration evidence | TSB integration outcomes and local/global decision split require refresh |
| `METH-001` | Researcher Operating Guide / CIOS Researcher pack | Method controls: evidence, observations, Unknowns, contradictions and no unsupported recommendations | Method authority; not Banking evidence |


## Source-use controls

| Control | Applied state |
|---|---|
| Source authority | Industry Twin and Enterprise Twins are treated as governed Banking evidence for this build. |
| Mechanism authority | Mechanism Catalogue and Matrix v2.1 control BM usage. |
| Observation authority | Observation Register controls canonical BK-OBS usage. |
| Hypothesis authority | Banking Reinvention Hypotheses v0.1 controls BRH usage. |
| Commercial material | Source opportunity material is interpreted only where linked to observations, mechanisms or hypotheses. |
| Supplier evidence | Supplier/provider-authored evidence remains limited unless independently corroborated in governed assets. |
| Human knowledge | None provided beyond the commission brief. |
| Freshness | Source assets effective 2026-07-17 to 2026-07-18; this release dated 2026-07-19. |

## Material evidence lineage examples

| Record | Lineage |
|---|---|
| `BK-MPI-OBS-003` | `ENT-NWVM-003` + `BANK-TWIN-001` -> `BK-OBS-029` / `BK-OBS-047` -> `BM-02` / `BM-04` / `BM-10` -> participant intelligence |
| `BK-MPI-OBS-004` | `ENT-MONZO-004` + `BANK-TWIN-001` -> `BK-OBS-013` / `BK-OBS-027` -> `BM-01` / `BM-03` / `BM-06` -> participant intelligence |
| `BK-MPI-OBS-008` | `BANK-INFRA-001` + `BANK-TWIN-001` -> `BK-OBS-021` to `BK-OBS-025` -> `BM-11` / `BM-13` / `BM-18` -> participant intelligence |
| `BK-MPI-OBS-009` | `BANK-FOUND-001` + `BANK-INFRA-001` + `BANK-OBS-001` -> `BK-OBS-017` / `BK-OBS-018` / `BK-OBS-045` / `BK-OBS-048` -> `BM-16` / `BM-17` / `BM-19` / `BM-20` -> participant intelligence |
