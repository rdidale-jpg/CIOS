# Strategic Whitespace Propositions

**Asset ID:** `EK-BANK-MPI-001-WS`  
**Effective date:** 2026-07-19  
**Governance:** Whitespace is a candidate commercial interpretation, not a recommendation or ranking.


---

## BK-WS-001 — Access-model evidence and service sustainability gap

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-001; BK-MP-005; BK-MP-006 |
| Proposition | Access-model evidence and service sustainability gap |
| Supporting evidence | Physical/assisted access changes create different exposures: incumbent cost/conduct, mutual trust/member value, challenger assisted-access dependency. |
| Supporting observations | BK-MPI-OBS-003; BK-MPI-OBS-004; BK-MPI-OBS-012 |
| Competitor / ecosystem context | Nationwide branch trust posture; Monzo digital-only/active-user model; Lloyds scale-incumbent access tension |
| Possible commercial relevance | Commercial relevance may exist in evidence-based access operating models, branch/hub/channel orchestration and vulnerable-customer outcome evidence. |
| Confidence | Medium |
| Unknowns | Quantified branch economics, customer-impact evidence and active programmes unknown. |
| Validation / invalidation test | Validated by participant-specific access strategy, outcome metrics, accountable owner and investment/procurement context; invalidated if no material access pressure or no addressable service seam exists. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-002 — Relationship-data platform gap in commercial banking

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-002; BK-MP-007 |
| Proposition | Relationship-data platform gap in commercial banking |
| Supporting evidence | NatWest validates commercial relationship-bank data/AI; Starling validates SME workflow surface. |
| Supporting observations | BK-MPI-OBS-002; BK-MPI-OBS-005 |
| Competitor / ecosystem context | NatWest relationship model versus Starling SME digital workflow |
| Possible commercial relevance | Commercial relevance may exist around KYB, RM augmentation, SME workflow data and relationship intelligence. |
| Confidence | Medium |
| Unknowns | Exact commercial banking platform architecture, realised benefits and procurement route unknown. |
| Validation / invalidation test | Validated by current programme/owner/budget evidence; invalidated if capability is already mature or fully contracted. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-003 — Governed AI outcome-evidence gap

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-001; BK-MP-002; BK-MP-003; BK-MP-004; BK-MP-009 |
| Proposition | Governed AI outcome-evidence gap |
| Supporting evidence | AI is visible, but independent outcome and control evidence remains weak across participant types. |
| Supporting observations | BK-OBS-019; BK-OBS-020; BK-OBS-048; BK-MPI-OBS-009 |
| Competitor / ecosystem context | Scale-bank AI, relationship-bank AI, global-platform AI and provider dependency create pressure. |
| Possible commercial relevance | Commercial relevance may exist around AI assurance, lineage, outcome measurement and operating-model governance. |
| Confidence | Medium |
| Unknowns | Deployed use cases, benefit realisation and model/control ownership unknown. |
| Validation / invalidation test | Validated by documented AI use cases with unresolved outcome/control burden; invalidated by strong internal assurance and benefit evidence or no buying route. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-004 — Cloud optionality and exit-planning gap

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-001; BK-MP-002; BK-MP-004; BK-MP-006; BK-MP-007; BK-MP-008; BK-MP-009 |
| Proposition | Cloud optionality and exit-planning gap |
| Supporting evidence | Cloud enables speed and migration but increases concentration/exit and resilience risk. |
| Supporting observations | BK-OBS-017; BK-OBS-018; BK-OBS-045; BK-MPI-OBS-009 |
| Competitor / ecosystem context | Critical third-party oversight and cloud-native challenger models create control pressure. |
| Possible commercial relevance | Commercial relevance may exist in resilience, portability, observability, workload mapping and assurance. |
| Confidence | Medium |
| Unknowns | Bank-by-bank workload maps, exit tests and contractual boundaries unknown. |
| Validation / invalidation test | Validated by exposed critical workloads, regulator pressure or migration programme; invalidated if exposure is low or already covered by mature controls. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-005 — Acquisition integration evidence gap

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-004; BK-MP-005 |
| Proposition | Acquisition integration evidence gap |
| Supporting evidence | Santander/TSB and Nationwide/Virgin Money are live tests of banking integration as reinvention catalyst and contradiction generator. |
| Supporting observations | BK-MPI-OBS-011; BK-OBS-043 |
| Competitor / ecosystem context | Santander global-platform integration and Nationwide mutual integration have different value logics. |
| Possible commercial relevance | Commercial relevance may exist around platform migration, data/customer migration, outcome evidence and benefits controls. |
| Confidence | Medium |
| Unknowns | Realised synergies, target architecture, sequencing and customer outcomes unknown. |
| Validation / invalidation test | Validated by integration programme gaps or public commitments; invalidated if all integration seams are internally resolved or inaccessible. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-006 — Fraud friction and trust operating model gap

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-001; BK-MP-006; BK-MP-007; BK-MP-008 |
| Proposition | Fraud friction and trust operating model gap |
| Supporting evidence | APP fraud/reimbursement and real-time payments make fraud a cross-ecosystem trust mechanism. |
| Supporting observations | BK-OBS-024; BK-OBS-036; BK-MPI-OBS-008; BK-MPI-OBS-010 |
| Competitor / ecosystem context | Infrastructure rules and challenger control maturity both create pressure. |
| Possible commercial relevance | Commercial relevance may exist around customer-friction design, fraud operations, CoP integration and reimbursement evidence. |
| Confidence | Medium |
| Unknowns | Bank-specific APP economics and false-positive/customer outcome data unknown. |
| Validation / invalidation test | Validated by fraud metrics, remediation or service friction evidence; invalidated if no material control or customer outcome gap exists. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-007 — Universal-bank mechanism gap

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-003 |
| Proposition | Universal-bank mechanism gap |
| Supporting evidence | Barclays requires additional capital-markets mechanisms to explain universal-bank behaviour. |
| Supporting observations | BK-MPI-OBS-006; BK-OBS-030 |
| Competitor / ecosystem context | Retail/commercial comparisons are insufficient for Barclays because IB/RWA/market risk dynamics matter. |
| Possible commercial relevance | Commercial relevance may exist in capital/RWA transparency, risk data, controls and platform simplification; mechanism status remains candidate. |
| Confidence | Low/Medium |
| Unknowns | Canonical acceptance of capital-markets mechanisms, platform map and buying route unknown. |
| Validation / invalidation test | Validated by accepted mechanism extension and platform/risk evidence; invalidated if scope stays retail/commercial only. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-008 — Infrastructure transition and bank-control boundary gap

| Field | Value |
|---|---|
| Affected participant(s) | BK-MP-008 plus all bank participants |
| Proposition | Infrastructure transition and bank-control boundary gap |
| Supporting evidence | Future retail payment infrastructure, CoP, APP, Open Banking and rail transition create shared constraints. |
| Supporting observations | BK-MPI-OBS-008; BK-OBS-021; BK-OBS-022; BK-OBS-025 |
| Competitor / ecosystem context | Banks own customer journeys but not reachability, settlement and rule layers. |
| Possible commercial relevance | Commercial relevance may exist where bank transformation depends on shared infrastructure readiness. |
| Confidence | Medium |
| Unknowns | RPIB, Delivery Company, operator and commercial model outcomes unknown. |
| Validation / invalidation test | Validated by transition roadmap and participant obligations; invalidated if no near-term dependency affects target bank. |
| Governance note | Candidate interpretation only; no action recommended. |

---

## BK-WS-009 — Outcome-evidence operating layer gap

| Field | Value |
|---|---|
| Affected participant(s) | All bank participants |
| Proposition | Outcome-evidence operating layer gap |
| Supporting evidence | Consumer Duty, trust, fraud, complaints and AI productivity create need for participant-specific outcome evidence. |
| Supporting observations | BK-OBS-040; BK-OBS-048; BK-MPI-OBS-012 |
| Competitor / ecosystem context | Regulated outcome evidence differentiates participants by trust, control and operating maturity. |
| Possible commercial relevance | Commercial relevance may exist around data lineage, evidence generation and operational control reporting. |
| Confidence | Medium |
| Unknowns | Outcome MI, owner and data architecture unknown. |
| Validation / invalidation test | Validated by regulatory findings, remediation or executive pressure; invalidated if outcome evidence is already mature and inaccessible. |
| Governance note | Candidate interpretation only; no action recommended. |
