# Participant Coverage Assessment

**Asset ID:** `EK-BANK-MPI-001-COV`  
**Effective date:** 2026-07-19

## Coverage principle

A participant is marked **meaningful governed coverage** only where existing Enterprise Knowledge supports participant-specific identity, market role, operating model, strategic direction, mechanism exposure, Unknowns and cross-participant comparison. Partial coverage is preserved rather than manufactured.

| Participant ID | Participant | Type | Coverage status | Primary evidence | Confidence |
|---|---|---|---|---|---|
| `BK-MP-001` | Lloyds Banking Group | Large retail incumbent / scale retail incumbent | Meaningful governed coverage — Wave 1 core | BK-OBS-005, BK-OBS-006, BK-OBS-008, BK-OBS-014, BK-OBS-032, BK-OBS-033 | High for scale incumbent economics; Medium for primacy renewal and specific commercial accessibility. |
| `BK-MP-002` | NatWest Group | UK commercial incumbent / relationship bank | Meaningful governed coverage — Wave 2 incumbent comparison | BK-OBS-003, BK-OBS-034, BK-OBS-037, BK-OBS-042 | High for commercial-relationship variant; Medium for AI outcome maturity and route/access. |
| `BK-MP-003` | Barclays | Universal bank | Meaningful governed coverage — Wave 2 incumbent comparison | BK-OBS-030, BK-OBS-039, BK-OBS-042 | High for need to model universal-bank variant; Medium for candidate mechanism completeness. |
| `BK-MP-004` | Santander UK | Multinational platform-bank subsidiary / UK ring-fenced bank | Meaningful governed coverage — Wave 2 incumbent comparison | BK-OBS-031, BK-OBS-043, BK-OBS-050 | High for global-platform/local-accountability variant; Medium for TSB integration outcome. |
| `BK-MP-005` | Nationwide / Virgin Money | Mutual or member-owned bank / building society with acquired bank integration | Meaningful governed coverage — Wave 1 core | BK-OBS-009, BK-OBS-029, BK-OBS-043, BK-OBS-047 | High for mutual/branch-trust variant; Medium for acquisition-integration outcomes. |
| `BK-MP-006` | Monzo | Digital-native consumer challenger | Meaningful governed coverage — Wave 1 core | BK-OBS-012, BK-OBS-013, BK-OBS-027, BK-OBS-049 | High for digital engagement/active-user conversion; Medium for durable majority primacy and lending economics. |
| `BK-MP-007` | Starling Bank | Digital-native SME/platform challenger | Meaningful governed coverage — Wave 3 challenger/ecosystem extension | BK-OBS-028, BK-OBS-049, BK-OBS-020, BK-OBS-018 | High for SME/platform challenger variant; Medium for external platform economics. |
| `BK-MP-008` | Pay.UK / UK retail payments infrastructure | Banking infrastructure participant | Meaningful governed coverage — Wave 1 infrastructure participant | BK-OBS-021, BK-OBS-022, BK-OBS-023, BK-OBS-024, BK-OBS-025 | High for control-boundary model; Medium for transition/ownership outcomes. |
| `BK-MP-009` | Critical third-party cloud and AI providers | Technology/platform/service participant cohort | Partial governed coverage — Wave 3 technology participant, cohort-level not full provider Twin | BK-OBS-017, BK-OBS-018, BK-OBS-045, BK-OBS-048 | Medium: role is strongly evidenced; individual provider-by-bank exposure is not. |

## Coverage by wave

| Wave | Participants | Coverage judgement | Rationale |
|---|---|---|---|
| Wave 1 — High-contrast core | Nationwide/Virgin Money, Lloyds, Monzo, Pay.UK / infrastructure | Meaningful governed coverage | Tests mutual, incumbent, challenger and ecosystem participant difference |
| Wave 2 — Incumbent comparison | NatWest, Barclays, Santander UK | Meaningful governed coverage | Tests differences among large participants: relationship bank, universal bank, global-platform subsidiary |
| Wave 3 — Challenger and ecosystem extension | Starling, critical third-party cloud/AI providers | Starling meaningful; technology participant partial | Starling has governed Enterprise Twin; technology providers are evidenced as systemic dependencies but not full provider Twins |

## Coverage status definitions

- **Meaningful governed coverage:** participant-specific current model, relevant mechanisms, observations, hypotheses and Unknowns exist.
- **Partial governed coverage:** role and dependency are evidenced, but participant-specific economic or operational anatomy is incomplete.
- **Excluded:** not included because evidence or scope does not support governed comparison in this release.

## Participants excluded from this release

| Participant | Reason |
|---|---|
| HSBC UK | Not part of initial commission cohort and no Enterprise Twin supplied in this workstream |
| Chase UK, Atom, Metro, Tandem | Named in industry context but no governed Enterprise Twin supplied for this commission |
| Cash Access UK / Post Office / LINK as separate Twins | Relevant to assisted access, but Pay.UK / infrastructure participant selected as the one infrastructure participant for first release |
| Individual hyperscalers as full Participant Twins | Governed assets evidence critical provider cohort; full provider-level bank exposure remains Unknown |

## Coverage refresh triggers

- New or refreshed Enterprise Twin for any participant.
- New accepted Observation Register entries that change participant exposure.
- New mechanism catalogue release.
- New payment infrastructure evidence on RPIB, Pay.UK, Vocalink, FPS, Bacs, CoP, APP or Open Banking.
- New evidence of bank-by-bank cloud workload concentration, exit planning or CTP dependency.
