# Delivery and Input Manifest — Banking Market Participant Intelligence

**Asset ID:** `EK-BANK-MPI-001`  
**Document class:** Governed Enterprise Knowledge asset / Market Participant Intelligence foundation  
**Repository path:** `enterprise-knowledge/banking/market-participant/`  
**Run mode:** New Build  
**Effective date:** 2026-07-19  
**Source cut-off:** Governed Banking assets with effective dates 2026-07-17 to 2026-07-18; commission brief received 2026-07-19.  
**Status:** Produced / Candidate; owner acceptance required.  
**Commission:** Build Governed Banking Market Participant Intelligence.  
**Not:** Product implementation, application code, UI, automated ranking logic, opportunity cards, CRM integration or new opportunity model.

## Named decision purpose

Enable Flora and later Codex implementation to reason over how major UK Banking participants differ, which market changes matter to each, what competitor actions create pressure, where commercial whitespace may exist, and what remains Unknown.

## Boundary

Included participant cohort:

- `BK-MP-001` — Lloyds Banking Group (Large retail incumbent / scale retail incumbent)
- `BK-MP-002` — NatWest Group (UK commercial incumbent / relationship bank)
- `BK-MP-003` — Barclays (Universal bank)
- `BK-MP-004` — Santander UK (Multinational platform-bank subsidiary / UK ring-fenced bank)
- `BK-MP-005` — Nationwide / Virgin Money (Mutual or member-owned bank / building society with acquired bank integration)
- `BK-MP-006` — Monzo (Digital-native consumer challenger)
- `BK-MP-007` — Starling Bank (Digital-native SME/platform challenger)
- `BK-MP-008` — Pay.UK / UK retail payments infrastructure (Banking infrastructure participant)
- `BK-MP-009` — Critical third-party cloud and AI providers (Technology/platform/service participant cohort)

Excluded:

- New external web research.
- Runtime scoring or ranking.
- Named individual executive mapping.
- Private account intelligence.
- Active opportunity cards.
- Full refresh of Enterprise Twins, Industry Twin, Mechanism Catalogue, Observation Register or Reinvention Hypotheses.

## Source register

| Source ID | Governed asset | Role in this build | Limitation |
|---|---|---|---|
| `BRIEF-001` | Pasted markdown.md — Build Governed Banking Market Participant Intelligence | Commission authority, scope, outputs and acceptance criteria | Commission instruction; not industry evidence |
| `BANK-FOUND-001` | Banking Industry Foundation | Participant taxonomy, industry boundary, source families and ecosystem participants | Foundation-level; not full participant twin |
| `BANK-TWIN-001` | Banking Industry Twin v1.0 | Synthesis source for participant variants, tensions, scope and current model | Canonical view but not a participant-specific register |
| `BANK-MECH-001` | Banking Mechanism Catalogue | Canonical BM-01 to BM-22 cross-reference authority | Mechanisms, not observations or participant moves |
| `BANK-OBS-001` | Banking Observation Register | Canonical BK-OBS-001 to BK-OBS-050 observation cross-reference authority | Existing observations only; new participant observations are candidate additions |
| `BANK-RHYP-001` | Banking Reinvention Hypotheses v0.1 | BRH-001 to BRH-014 opportunity/hypothesis reference set | Hypotheses are learning objects, not predictions or recommendations |
| `BANK-INFRA-001` | UK Banking Payments Infrastructure Twin v0.1 | Infrastructure participant, control-boundary and shared-rail evidence | Public infrastructure evidence; not a bank enterprise twin |
| `BANK-MATRIX-001` | Four-Bank Mechanism Differential Matrix v2.1 | Corrected BM identifier discipline and mechanism confidence boundary | Matrix covers selected participants; not exhaustive |
| `ENT-LBG-001` | Lloyds Banking Group Enterprise Twin + Deepening | Scale incumbent participant evidence | Public evidence boundary; salary/direct-debit primacy remains unknown |
| `ENT-NTW-002` | NatWest Group Enterprise Twin | Commercial incumbent and AI relationship-bank variant evidence | Public evidence boundary; route/procurement detail incomplete |
| `ENT-NWVM-003` | Nationwide / Virgin Money Enterprise Twin | Mutual/member-value, branch trust and integration evidence | Realised Virgin Money integration benefits remain uncertain |
| `ENT-MONZO-004` | Monzo Bank Enterprise Twin | Consumer challenger primary-conversion and growth-control evidence | Public primacy metric is active-user based, not all registered customers |
| `ENT-STAR-005` | Starling Bank Enterprise Twin | SME-weighted challenger and platform-export evidence | Exact Engine/platform commercial economics not fully visible |
| `ENT-BARC-006` | Barclays Enterprise Twin | Universal-bank portfolio and capital-markets candidate evidence | Investment-bank mechanism set remains candidate, not canonical |
| `ENT-SAN-007` | Santander UK Enterprise Twin | Multinational platform-bank subsidiary and TSB integration evidence | TSB integration outcomes and local/global decision split require refresh |
| `METH-001` | Researcher Operating Guide / CIOS Researcher pack | Method controls: evidence, observations, Unknowns, contradictions and no unsupported recommendations | Method authority; not Banking evidence |


## Deliverables created

1. `00-Delivery-and-Input-Manifest.md`
2. `01-Repository-Reconnaissance-Report.md`
3. `02-Participant-Coverage-Assessment.md`
4. `03-Initial-Banking-Participant-Cohort.md`
5. `04-Governed-Market-Participant-Twins.md`
6. `05-New-Banking-Participant-Observations.md`
7. `06-Competitor-Move-Records.md`
8. `07-Competitive-Relationship-Records.md`
9. `08-Banking-Participant-Comparison-Matrix.md`
10. `09-Opportunity-to-Participant-Analysis.md`
11. `10-Strategic-Whitespace-Propositions.md`
12. `11-Participant-Specific-Executive-Role-Analysis.md`
13. `12-Unknown-Register.md`
14. `13-Contradiction-Register.md`
15. `14-Evidence-Source-Register.md`
16. `15-Research-Limitations.md`
17. `16-Codex-Implementation-Handoff.md`
18. `17-Validation-Report.md`
19. `18-Completion-Report.md`
20. `COMMIT.md`
21. `PULL_REQUEST.md`

## Delivery validation performed

- Files written to repository-relative path inside release folder.
- Markdown files opened and non-empty checked.
- Cross-reference IDs checked against local mechanism, observation and hypothesis registers where available.
- Release ZIP created.
- Local git commit attempted and recorded in completion report.

## Human-supplied knowledge

No private human-supplied account knowledge was provided in this run. The commission brief is treated as instruction, not evidence.
