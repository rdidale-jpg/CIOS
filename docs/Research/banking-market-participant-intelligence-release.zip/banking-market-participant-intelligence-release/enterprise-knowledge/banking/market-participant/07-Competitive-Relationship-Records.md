# Competitive Relationship Records

**Asset ID:** `EK-BANK-MPI-001-REL`  
**Effective date:** 2026-07-19

## Governance

Relationships are created only where they are commercially meaningful and supported by governed participant evidence. Generic `competes_with` relationships are not used.


---

## BK-REL-001

```yaml
relationship_id: BK-REL-001
source_participant: BK-MP-005
relationship_type: differentiates_from
target_participant: BK-MP-001
context: Physical/assisted access
supporting_evidence: Nationwide branch/member-value posture differs from Lloyds branch/access pressure and digital simplification posture.
supporting_observations: [BK-MPI-OBS-003; BK-MPI-OBS-001]
affected_mechanisms: [BM-04; BM-02; BM-15]
confidence: High
unknowns: Quantified economic effect unknown.
contradictions: Branch can be both cost and trust asset depending on participant type.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-002

```yaml
relationship_id: BK-REL-002
source_participant: BK-MP-006
relationship_type: creates_pressure_on
target_participant: BK-MP-001
context: Current-account primacy
supporting_evidence: Monzo active-user primary conversion pressures incumbent primacy and deposit relationships without proving whole-base primacy.
supporting_observations: [BK-MPI-OBS-004; BK-MPI-OBS-001]
affected_mechanisms: [BM-01; BM-03; BM-06]
confidence: High
unknowns: Salary-flow/direct debit concentration unknown.
contradictions: Digital engagement is not equivalent to whole-base primacy.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-003

```yaml
relationship_id: BK-REL-003
source_participant: BK-MP-007
relationship_type: creates_pressure_on
target_participant: BK-MP-002
context: SME relationship surface
supporting_evidence: Starling’s SME-weighted digital workflow model pressures commercial relationship models where SME workflows, onboarding and data are fragmented.
supporting_observations: [BK-MPI-OBS-005; BK-MPI-OBS-002]
affected_mechanisms: [BM-05; BM-12; BM-22]
confidence: Medium
unknowns: Extent of direct customer overlap and switching unknown.
contradictions: SME challenger and commercial incumbent serve overlapping but not identical customer models.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-004

```yaml
relationship_id: BK-REL-004
source_participant: BK-MP-004
relationship_type: depends_on
target_participant: Banco Santander group platforms
context: Local/global platform control
supporting_evidence: Santander UK relies on global parent platform and operating-model convergence while remaining locally regulated and accountable.
supporting_observations: [BK-MPI-OBS-007]
affected_mechanisms: [BM-16; BM-19; BM-10]
confidence: High
unknowns: Decision-right split and TSB target architecture unknown.
contradictions: Acceleration can coexist with accountability complexity.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-005

```yaml
relationship_id: BK-REL-005
source_participant: BK-MP-001; BK-MP-002; BK-MP-003; BK-MP-004; BK-MP-005; BK-MP-006; BK-MP-007
relationship_type: depends_on
target_participant: BK-MP-008
context: Payments reachability and settlement
supporting_evidence: Banks depend on shared payment infrastructure for reachability, clearing, settlement, CoP, APP rule embedding and open-banking payment execution.
supporting_observations: [BK-MPI-OBS-008]
affected_mechanisms: [BM-11; BM-13; BM-18]
confidence: High
unknowns: Specific participant incident exposure and roadmaps unknown.
contradictions: Bank UX ownership does not imply rail ownership.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-006

```yaml
relationship_id: BK-REL-006
source_participant: BK-MP-001; BK-MP-002; BK-MP-003; BK-MP-004; BK-MP-005; BK-MP-006; BK-MP-007; BK-MP-008
relationship_type: depends_on
target_participant: BK-MP-009
context: Cloud, AI and technology resilience
supporting_evidence: Banks and infrastructure depend on common cloud/AI/platform providers, creating concentration and exit risk.
supporting_observations: [BK-MPI-OBS-009]
affected_mechanisms: [BM-16; BM-17; BM-19; BM-20]
confidence: Medium
unknowns: Bank-by-bank workload maps and exit plans unknown.
contradictions: Cloud acceleration vs systemic dependency remains a tension.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-007

```yaml
relationship_id: BK-REL-007
source_participant: BK-MP-003
relationship_type: differentiates_from
target_participant: BK-MP-001; BK-MP-002
context: Universal-bank portfolio
supporting_evidence: Barclays requires retail/commercial plus capital-markets candidate mechanisms, unlike retail/commercial-focused incumbents.
supporting_observations: [BK-MPI-OBS-006]
affected_mechanisms: [BM-10 plus candidate mechanisms]
confidence: High
unknowns: Accepted canonical mechanism expansion not yet complete.
contradictions: One group Twin can represent Barclays, but one retail/commercial BM set cannot explain all dynamics.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-008

```yaml
relationship_id: BK-REL-008
source_participant: BK-MP-002
relationship_type: benchmarks_against
target_participant: BK-MP-001
context: Incumbent comparison
supporting_evidence: NatWest and Lloyds both have incumbent deposit/current-account economics, but NatWest’s visible C&I relationship model creates a distinct comparison lens.
supporting_observations: [BK-MPI-OBS-002; BK-MPI-OBS-001]
affected_mechanisms: [BM-05; BM-06; BM-17; BM-20]
confidence: High
unknowns: Precise product/channel overlap and switching pressure not established.
contradictions: Incumbent similarity should not erase commercial-bank distinction.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-009

```yaml
relationship_id: BK-REL-009
source_participant: BK-MP-006
relationship_type: differentiates_from
target_participant: BK-MP-007
context: Digital challenger variant
supporting_evidence: Monzo validates consumer active-user primary conversion, while Starling validates SME/platform challenger banking.
supporting_observations: [BK-MPI-OBS-004; BK-MPI-OBS-005]
affected_mechanisms: [BM-03; BM-05; BM-22]
confidence: High
unknowns: Comparative cohort economics and product-depth by customer segment unknown.
contradictions: Both are challengers, but not the same challenger mechanism.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```

---

## BK-REL-010

```yaml
relationship_id: BK-REL-010
source_participant: BK-MP-008
relationship_type: constrains
target_participant: All bank participants
context: Infrastructure control boundary
supporting_evidence: Infrastructure participant rules and settlement layers constrain what bank-local transformation can do in payments, fraud and open banking.
supporting_observations: [BK-MPI-OBS-008]
affected_mechanisms: [BM-11; BM-13; BM-18]
confidence: High
unknowns: Future retail infrastructure transition unresolved.
contradictions: Infrastructure-owned constraints should not be interpreted as bank-specific failure.
freshness: Current to governed source cut-off; refresh on new participant evidence.
```
