# Governed Market Participant Twins

**Asset ID:** `EK-BANK-MPI-001-TWINS`  
**Document class:** Governed Enterprise Knowledge asset / Market Participant Twin foundation  
**Effective date:** 2026-07-19  
**Status:** Candidate participant-intelligence release; not a replacement for Enterprise Twins.

## Governance

These are Market Participant Twins by reference. They do not duplicate or replace full Enterprise Twins. Each record captures comparable fields requested in the commission and points back to governed source assets, observations, mechanisms and hypotheses.


---

## BK-MP-001 — Lloyds Banking Group

```yaml
participant_id: BK-MP-001
participant_name: Lloyds Banking Group
participant_type: Large retail incumbent / scale retail incumbent
ownership_model: Listed UK banking group
market_role: UK-focused scale retail and commercial bank; reference case for deposit/current-account, structural hedge and NII investment-capacity loop.
customer_segments: Retail current-account, savings, mortgage, cards, commercial and selected integrated financial-services customers.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: UK-focused scale retail and commercial bank; reference case for deposit/current-account, structural hedge and NII investment-capacity loop.
distribution_model: Mobile-first and digital migration with branch/brand rationalisation and assisted-channel obligations.
strategic_position: Defends scale primacy through deposit franchise, structural hedge income, capital discipline, simplification, technology/data/AI and integrated financial-services adjacency.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: Salary-flow/direct-debit primacy evidence remains incomplete; legacy simplification, branch access, conduct, fraud, cloud/core migration and motor/remediation risks shape attention.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: Salary-flow/direct-debit primacy evidence remains incomplete; legacy simplification, branch access, conduct, fraud, cloud/core migration and motor/remediation risks shape attention.
distinctive_capabilities: Defends scale primacy through deposit franchise, structural hedge income, capital discipline, simplification, technology/data/AI and integrated financial-services adjacency.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-01, BM-06, BM-07, BM-10, BM-15, BM-16, BM-17, BM-20]
relevant_observations: [BK-OBS-005, BK-OBS-006, BK-OBS-008, BK-OBS-014, BK-OBS-032, BK-OBS-033]
relevant_hypotheses: [BRH-001, BRH-002, BRH-007, BRH-009, BRH-014]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for scale incumbent economics; Medium for primacy renewal and specific commercial accessibility.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 1 core
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Lloyds Banking Group is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-005, BK-OBS-006, BK-OBS-008, BK-OBS-014, BK-OBS-032, BK-OBS-033; mechanisms: BM-01, BM-06, BM-07, BM-10, BM-15, BM-16, BM-17, BM-20; hypotheses: BRH-001, BRH-002, BRH-007, BRH-009, BRH-014. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-002 — NatWest Group

```yaml
participant_id: BK-MP-002
participant_name: NatWest Group
participant_type: UK commercial incumbent / relationship bank
ownership_model: Listed UK banking group
market_role: Retail and Commercial & Institutional relationship bank; validates commercial relationship-data and AI-enabled relationship-bank variant.
customer_segments: Retail, private/wealth where material, business, SME, commercial and institutional customers.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: Retail and Commercial & Institutional relationship bank; validates commercial relationship-data and AI-enabled relationship-bank variant.
distribution_model: Hybrid digital, relationship-manager, Bankline/API and branch/contact-centre model.
strategic_position: Uses commercial deposits, lending, FX, cash management, APIs, relationship managers, cloud/data and AI to deepen relationships.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: KYB/control friction, data/platform dependency, evidence of realised AI relationship outcomes, procurement/access route and exact supplier workshare remain incomplete.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: KYB/control friction, data/platform dependency, evidence of realised AI relationship outcomes, procurement/access route and exact supplier workshare remain incomplete.
distinctive_capabilities: Uses commercial deposits, lending, FX, cash management, APIs, relationship managers, cloud/data and AI to deepen relationships.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-03, BM-05, BM-06, BM-12, BM-17, BM-20]
relevant_observations: [BK-OBS-003, BK-OBS-034, BK-OBS-037, BK-OBS-042]
relevant_hypotheses: [BRH-004, BRH-007, BRH-009, BRH-014]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for commercial-relationship variant; Medium for AI outcome maturity and route/access.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 2 incumbent comparison
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

NatWest Group is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-003, BK-OBS-034, BK-OBS-037, BK-OBS-042; mechanisms: BM-03, BM-05, BM-06, BM-12, BM-17, BM-20; hypotheses: BRH-004, BRH-007, BRH-009, BRH-014. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-003 — Barclays

```yaml
participant_id: BK-MP-003
participant_name: Barclays
participant_type: Universal bank
ownership_model: Listed UK-headquartered universal banking group
market_role: Retail, UK corporate, wealth, cards, US consumer and Investment Bank participant; proof case that universal banking requires controlled-adjacency modelling.
customer_segments: UK retail, corporate and transaction banking, private/wealth, cards, US consumer and institutional/capital-markets clients.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: Retail, UK corporate, wealth, cards, US consumer and Investment Bank participant; proof case that universal banking requires controlled-adjacency modelling.
distribution_model: Multi-channel retail/commercial plus capital-markets and institutional platforms.
strategic_position: Balances retail/commercial stability with Investment Bank, cards, wealth and global capital allocation.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: Canonical retail/commercial BM set is insufficient for investment-bank dynamics; capital-markets candidates need separate validation; supplier and exact route data incomplete.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: Canonical retail/commercial BM set is insufficient for investment-bank dynamics; capital-markets candidates need separate validation; supplier and exact route data incomplete.
distinctive_capabilities: Balances retail/commercial stability with Investment Bank, cards, wealth and global capital allocation.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-10 plus Barclays candidate mechanisms; BM-01, BM-05, BM-06 where retail/commercial apply]
relevant_observations: [BK-OBS-030, BK-OBS-039, BK-OBS-042]
relevant_hypotheses: [BRH-012, BRH-010, BRH-007]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for need to model universal-bank variant; Medium for candidate mechanism completeness.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 2 incumbent comparison
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Barclays is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-030, BK-OBS-039, BK-OBS-042; mechanisms: BM-10 plus Barclays candidate mechanisms; BM-01, BM-05, BM-06 where retail/commercial apply; hypotheses: BRH-012, BRH-010, BRH-007. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-004 — Santander UK

```yaml
participant_id: BK-MP-004
participant_name: Santander UK
participant_type: Multinational platform-bank subsidiary / UK ring-fenced bank
ownership_model: UK ring-fenced bank owned by Banco Santander group
market_role: UK mortgage/deposit bank operating inside global Santander platform, technology and operating-model convergence agenda.
customer_segments: UK retail, mortgage, deposits, current accounts, business banking and TSB-acquired customers where integrated.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: UK mortgage/deposit bank operating inside global Santander platform, technology and operating-model convergence agenda.
distribution_model: UK digital, branch, contact centre and group-platform-enabled banking channels.
strategic_position: Local UK banking accountability combined with Banco Santander global platforms, ONE Transformation, Gravity, Data & AI, Openbank/PagoNxt and TSB integration.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: TSB integration outcomes, local/global decision-right split, group platform dependency, branch strategy and local accountability need refresh.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: TSB integration outcomes, local/global decision-right split, group platform dependency, branch strategy and local accountability need refresh.
distinctive_capabilities: Local UK banking accountability combined with Banco Santander global platforms, ONE Transformation, Gravity, Data & AI, Openbank/PagoNxt and TSB integration.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-06, BM-08, BM-10, BM-16, BM-19, BM-22]
relevant_observations: [BK-OBS-031, BK-OBS-043, BK-OBS-050]
relevant_hypotheses: [BRH-008, BRH-011, BRH-010, BRH-014]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for global-platform/local-accountability variant; Medium for TSB integration outcome.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 2 incumbent comparison
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Santander UK is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-031, BK-OBS-043, BK-OBS-050; mechanisms: BM-06, BM-08, BM-10, BM-16, BM-19, BM-22; hypotheses: BRH-008, BRH-011, BRH-010, BRH-014. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-005 — Nationwide / Virgin Money

```yaml
participant_id: BK-MP-005
participant_name: Nationwide / Virgin Money
participant_type: Mutual or member-owned bank / building society with acquired bank integration
ownership_model: Mutual/member-owned building society; former Virgin Money business transferred/integrating
market_role: Mortgage-and-savings scale mutual using member value, trust and branch promise as strategic differentiation; Virgin Money adds diversification and integration pressure.
customer_segments: Members, retail savings, mortgages, current accounts, consumer lending, branch/contact-centre users and inherited business banking customers.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: Mortgage-and-savings scale mutual using member value, trust and branch promise as strategic differentiation; Virgin Money adds diversification and integration pressure.
distribution_model: Branch commitment, contact-centre, digital and inherited Virgin Money channels.
strategic_position: Allocates surplus between capital strength, member value, rewards, pricing, service, branches and integration, rather than shareholder distributions.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: Mortgage concentration, branch-cost sustainability, member-value proof, platform duplication and realised integration benefits remain important Unknowns.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: Mortgage concentration, branch-cost sustainability, member-value proof, platform duplication and realised integration benefits remain important Unknowns.
distinctive_capabilities: Allocates surplus between capital strength, member value, rewards, pricing, service, branches and integration, rather than shareholder distributions.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-02, BM-04, BM-06, BM-08, BM-10, BM-15, BM-16]
relevant_observations: [BK-OBS-009, BK-OBS-029, BK-OBS-043, BK-OBS-047]
relevant_hypotheses: [BRH-003, BRH-011, BRH-013, BRH-014]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for mutual/branch-trust variant; Medium for acquisition-integration outcomes.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 1 core
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Nationwide / Virgin Money is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-009, BK-OBS-029, BK-OBS-043, BK-OBS-047; mechanisms: BM-02, BM-04, BM-06, BM-08, BM-10, BM-15, BM-16; hypotheses: BRH-003, BRH-011, BRH-013, BRH-014. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-006 — Monzo

```yaml
participant_id: BK-MP-006
participant_name: Monzo
participant_type: Digital-native consumer challenger
ownership_model: Private regulated banking group
market_role: App-led challenger converting active users into primary banking relationships while growing deposits, products and profitability.
customer_segments: Consumer current-account, savings, payments, borrowing, wealth/subscriptions and business banking users; active-user base is analytically distinct from registered base.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: App-led challenger converting active users into primary banking relationships while growing deposits, products and profitability.
distribution_model: App-first, digital-only/direct, low-friction onboarding, customer-service and ecosystem integrations; assisted access is indirect/partner-dependent where applicable.
strategic_position: Uses digital engagement, service quality, product adjacency, subscriptions, deposits and European expansion to challenge incumbent relationship control.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: Public primacy evidence is active-user based; salary flow, direct debit concentration, cohort economics, lending discipline, capital/RWA maturity and control maturity require validation.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: Public primacy evidence is active-user based; salary flow, direct debit concentration, cohort economics, lending discipline, capital/RWA maturity and control maturity require validation.
distinctive_capabilities: Uses digital engagement, service quality, product adjacency, subscriptions, deposits and European expansion to challenge incumbent relationship control.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-01, BM-03, BM-06, BM-09, BM-11, BM-12, BM-16, BM-19]
relevant_observations: [BK-OBS-012, BK-OBS-013, BK-OBS-027, BK-OBS-049]
relevant_hypotheses: [BRH-001, BRH-002, BRH-006, BRH-010]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for digital engagement/active-user conversion; Medium for durable majority primacy and lending economics.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 1 core
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Monzo is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-012, BK-OBS-013, BK-OBS-027, BK-OBS-049; mechanisms: BM-01, BM-03, BM-06, BM-09, BM-11, BM-12, BM-16, BM-19; hypotheses: BRH-001, BRH-002, BRH-006, BRH-010. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-007 — Starling Bank

```yaml
participant_id: BK-MP-007
participant_name: Starling Bank
participant_type: Digital-native SME/platform challenger
ownership_model: Private banking and platform group
market_role: Profitable SME-weighted digital bank with own banking platform exported through Engine and workflow adjacency through SME operations.
customer_segments: SME business banking, retail banking, platform clients through Engine, Fleet/Ember adjacencies where material.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: Profitable SME-weighted digital bank with own banking platform exported through Engine and workflow adjacency through SME operations.
distribution_model: App-first, digital-direct, business workflow integrations and platform export.
strategic_position: Turns SME account into workflow surface for cash, tax, bookkeeping, invoicing and compliance while also operating platform-provider role.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: Financial-crime remediation memory, Engine commercial economics, exact platform workshare, cloud exit planning and adoption maturity remain Unknowns.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: Financial-crime remediation memory, Engine commercial economics, exact platform workshare, cloud exit planning and adoption maturity remain Unknowns.
distinctive_capabilities: Turns SME account into workflow surface for cash, tax, bookkeeping, invoicing and compliance while also operating platform-provider role.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-03, BM-05, BM-06, BM-11, BM-12, BM-16, BM-19, BM-22]
relevant_observations: [BK-OBS-028, BK-OBS-049, BK-OBS-020, BK-OBS-018]
relevant_hypotheses: [BRH-004, BRH-007, BRH-008, BRH-010]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for SME/platform challenger variant; Medium for external platform economics.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 3 challenger/ecosystem extension
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Starling Bank is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-028, BK-OBS-049, BK-OBS-020, BK-OBS-018; mechanisms: BM-03, BM-05, BM-06, BM-11, BM-12, BM-16, BM-19, BM-22; hypotheses: BRH-004, BRH-007, BRH-008, BRH-010. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-008 — Pay.UK / UK retail payments infrastructure

```yaml
participant_id: BK-MP-008
participant_name: Pay.UK / UK retail payments infrastructure
participant_type: Banking infrastructure participant
ownership_model: Industry infrastructure operator / public-interest payments infrastructure role
market_role: Operates or governs retail payments operations and overlay services that define reachability, rules, settlement interfaces, CoP, Request to Pay and retail rail transition boundaries.
customer_segments: Banks, PSPs, payment initiators/receivers, businesses, government, indirect access providers and overlay-service participants.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: Operates or governs retail payments operations and overlay services that define reachability, rules, settlement interfaces, CoP, Request to Pay and retail rail transition boundaries.
distribution_model: Infrastructure rails, directories, standards, rules and participant access rather than retail bank distribution.
strategic_position: Constrains and enables bank propositions by controlling interoperability, availability, rules, standards and overlay services no single bank owns.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: Future retail payment infrastructure transition, Vocalink contract/ownership signals, open-banking support economics and RPIB outcomes require refresh.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: Future retail payment infrastructure transition, Vocalink contract/ownership signals, open-banking support economics and RPIB outcomes require refresh.
distinctive_capabilities: Constrains and enables bank propositions by controlling interoperability, availability, rules, standards and overlay services no single bank owns.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-11, BM-13, BM-18]
relevant_observations: [BK-OBS-021, BK-OBS-022, BK-OBS-023, BK-OBS-024, BK-OBS-025]
relevant_hypotheses: [BRH-005, BRH-006, BRH-003]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: High for control-boundary model; Medium for transition/ownership outcomes.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Meaningful governed coverage — Wave 1 infrastructure participant
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Pay.UK / UK retail payments infrastructure is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-021, BK-OBS-022, BK-OBS-023, BK-OBS-024, BK-OBS-025; mechanisms: BM-11, BM-13, BM-18; hypotheses: BRH-005, BRH-006, BRH-003. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.

---

## BK-MP-009 — Critical third-party cloud and AI providers

```yaml
participant_id: BK-MP-009
participant_name: Critical third-party cloud and AI providers
participant_type: Technology/platform/service participant cohort
ownership_model: External technology/platform providers designated or treated as critical dependencies in governed assets
market_role: Provide cloud, AI, infrastructure, data, analytics and developer platforms that support bank technology, data, AI and resilience operating models.
customer_segments: Banks, PSPs, financial-market infrastructures and technology ecosystems.
geographic_scope: UK Banking relevance unless noted; infrastructure and technology participants operate at ecosystem or platform layer.
business_model: Provide cloud, AI, infrastructure, data, analytics and developer platforms that support bank technology, data, AI and resilience operating models.
distribution_model: Platform and managed technology services rather than banking distribution.
strategic_position: Creates regulated dependency and optionality pressure: banks gain speed and AI/cloud capability while inheriting concentration, exit and assurance burdens.
strategic_ambitions: Evidenced through governed source Twins only; no new strategy invented.
transformation_pressures: Bank-by-bank workload maps, exit plans, contract boundaries, resilience testing results and exact dependency concentration are largely Unknown.
active_programmes: Refer to source Enterprise Twin or Infrastructure Twin; programme status not inferred where not evidenced.
technology_constraints: Legacy/core/cloud/data/AI/resilience constraints where supported by related observations and mechanisms.
operating_model_constraints: Bank-by-bank workload maps, exit plans, contract boundaries, resilience testing results and exact dependency concentration are largely Unknown.
distinctive_capabilities: Creates regulated dependency and optionality pressure: banks gain speed and AI/cloud capability while inheriting concentration, exit and assurance burdens.
competitive_posture: Participant-specific variant; not converted into ranking.
executive_roles: See 11-Participant-Specific-Executive-Role-Analysis.md
relevant_mechanisms: [BM-16, BM-17, BM-19, BM-20, BM-13]
relevant_observations: [BK-OBS-017, BK-OBS-018, BK-OBS-045, BK-OBS-048]
relevant_hypotheses: [BRH-007, BRH-008, BRH-014]
competitor_relationships: See 07-Competitive-Relationship-Records.md
ecosystem_relationships: See infrastructure and technology dependency records where relevant.
opportunity_implications: See 09-Opportunity-to-Participant-Analysis.md
evidence_strength: Medium: role is strongly evidenced; individual provider-by-bank exposure is not.
freshness: Current to governed source cut-off 2026-07-17/18; refresh required on material new evidence.
unknowns: See 12-Unknown-Register.md
contradictions: See 13-Contradiction-Register.md
authority: BANK-TWIN-001 plus participant source Twin and canonical BM/BK-OBS/BRH assets.
status: Partial governed coverage — Wave 3 technology participant, cohort-level not full provider Twin
lineage: BRIEF-001 -> governed Banking assets -> participant intelligence record.
```

### Participant-specific judgement

Critical third-party cloud and AI providers is included because governed evidence supports a materially distinct participant type and a different exposure to shared Banking changes. This record is not a profile; it preserves the participant-specific commercial judgement needed for comparison.

### Evidence boundary

Primary evidence: BK-OBS-017, BK-OBS-018, BK-OBS-045, BK-OBS-048; mechanisms: BM-16, BM-17, BM-19, BM-20, BM-13; hypotheses: BRH-007, BRH-008, BRH-014. No private account knowledge or new external evidence was added.

### Refresh triggers

- New annual/results evidence or strategic update.
- Material programme, acquisition, integration, platform, cloud, AI, branch/access, payments, fraud or regulatory evidence.
- New accepted Observation Register or Mechanism Catalogue version.
