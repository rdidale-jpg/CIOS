# Repository Reconnaissance Report — Banking Market Participant Intelligence

**Asset ID:** `EK-BANK-MPI-001-RR`  
**Parent asset:** `EK-BANK-MPI-001`  
**Run mode:** New Build  
**Effective date:** 2026-07-19

## Purpose

Review the governed Banking repository assets before creating Market Participant Intelligence, so this asset references existing Enterprise Knowledge rather than redefining Industry, Mechanism, Observation or Reinvention assets.

## Assets reviewed

| Source ID | Governed asset | Role in this build | Limitation |
|---|---|---|---|
| `BRIEF-001` | Pasted markdown.md — Build Governed Banking Market Participant Intelligence | Commission authority, scope, outputs and acceptance criteria | Commission instruction; not industry evidence |
| `BANK-FOUND-001` | Banking Industry Foundation | Participant taxonomy, industry boundary, source families and ecosystem participants | Foundation-level; not full participant twin |
| `BANK-TWIN-001` | Banking Industry Twin v1.0 | Synthesis source for participant variants, tensions, scope and current model | Canonical view but not a participant-specific register |
| `BANK-MECH-001` | Banking Mechanism Catalogue | Canonical BM-01 to BM-22 cross-reference authority | Mechanisms, not observations or participant moves |
| `BANK-OBS-001` | Banking Observation Register | Canonical BK-OBS-001 to BK-OBS-050 observation cross-reference authority | Existing observations only; new participant observations are candidate additions |
| `BANK-RHYP-001` | Banking Reinvention Hypotheses v0.1 | BRH-001 to BRH-014 opportunity/hypothesis reference set | Hypotheses are learning objects, not predictions or recommendations |
| `BANK-INFRA-001` | UK Banking Payments Infrastructure Twin v0.1 | Infrastructure participant, control-boundary and shared-rail evidence | Public infrastructure evidence; not a bank enterprise twin |
| `BANK-MATRIX-001` | Four-Bank Mechanism Differential Matrix v2.1 | Corrected BM identifier discipline and mechanism confidence boundary | Matrix covers selected participants; not exhaustive |
| `ENT-LBG-001` | Lloyds Banking Group Enterprise Twin + Deepening | Scale incumbent participant evidence | Public evidence boundary; salary/direct-debit primacy remains unknown |
| `ENT-NTW-002` | NatWest Group Enterprise Twin | Commercial incumbent and AI relationship-bank variant evidence | Public evidence boundary; route/procurement detail incomplete |
| `ENT-NWVM-003` | Nationwide / Virgin Money Enterprise Twin | Mutual/member-value, branch trust and integration evidence | Realised Virgin Money integration benefits remain uncertain |
| `ENT-MONZO-004` | Monzo Bank Enterprise Twin | Consumer challenger primary-conversion and growth-control evidence | Public primacy metric is active-user based, not all registered customers |
| `ENT-STAR-005` | Starling Bank Enterprise Twin | SME-weighted challenger and platform-export evidence | Exact Engine/platform commercial economics not fully visible |
| `ENT-BARC-006` | Barclays Enterprise Twin | Universal-bank portfolio and capital-markets candidate evidence | Investment-bank mechanism set remains candidate, not canonical |
| `ENT-SAN-007` | Santander UK Enterprise Twin | Multinational platform-bank subsidiary and TSB integration evidence | TSB integration outcomes and local/global decision split require refresh |
| `METH-001` | Researcher Operating Guide / CIOS Researcher pack | Method controls: evidence, observations, Unknowns, contradictions and no unsupported recommendations | Method authority; not Banking evidence |


## Existing knowledge recovered

| Knowledge object | Existing asset | Reuse in this build |
|---|---|---|
| Banking industry model | `BANK-TWIN-001` | Current enterprise model, participant variants, infrastructure boundary and industry tensions |
| Banking mechanisms | `BANK-MECH-001` | Canonical BM references only; mechanisms are not redefined here |
| Banking observations | `BANK-OBS-001` | Canonical BK-OBS references; existing observations are not rewritten here |
| Banking reinvention hypotheses | `BANK-RHYP-001` | BRH references for opportunity-to-participant analysis |
| Participant evidence | Enterprise Twins `ENT-LBG-001` to `ENT-SAN-007` | Participant-specific facts, variants, Unknowns and contradictions |
| Infrastructure evidence | `BANK-INFRA-001` | Payment infrastructure participant and control-boundary model |
| Mechanism confidence corrections | `BANK-MATRIX-001` | Prevents mechanism identifier drift and local-label misuse |
| Technology/service participant evidence | `BANK-FOUND-001`, `BANK-INFRA-001`, observations | Supports cohort-level cloud/hyperscaler participant treatment only |

## Material repository findings

1. The governed Banking model is participant-variant driven: no single bank type represents the industry.
2. The Industry Twin already identifies material variants: scale incumbent, commercial incumbent, mutual, consumer challenger, SME/platform challenger, universal bank, multinational platform-bank subsidiary and infrastructure participant.
3. The Mechanism Catalogue already owns canonical BM-01 to BM-22; this asset references those mechanisms rather than redefining them.
4. The Observation Register already owns BK-OBS-001 to BK-OBS-050; this build creates candidate participant-intelligence observations only where comparison needs additional structured records.
5. The Reinvention Hypotheses asset already owns BRH-001 to BRH-014; this build assesses participant relevance but does not create new hypotheses.
6. Payment infrastructure cannot be treated as a bank-local capability because several mechanisms depend on shared rails, schemes, rules, settlement and overlay services.
7. Technology/platform providers can be included only at participant-cohort level because governed assets evidence systemic dependency but not complete bank-by-bank workload maps.

## Gaps before this build

| Gap | Consequence | Treatment |
|---|---|---|
| No governed participant-comparison asset | Flora can describe participants but cannot reliably compare implications | Create comparative participant intelligence foundation |
| No competitor-move register | Moves are scattered across Twins and observations | Create evidence-backed move records |
| No competitive relationship register | Relationships risk becoming generic `competes_with` claims | Create contextual relationships only |
| No participant-specific hypothesis relevance matrix | BRH hypotheses are industry-wide, not participant-specific | Create qualitative opportunity-to-participant analysis |
| No Codex handoff | Later implementation could invent fields or ranking logic | Create safe field handoff and unsafe-for-ranking warnings |

## Boundary decision

This is a participant intelligence asset. It does not amend the Industry Twin, Mechanism Catalogue, Observation Register or Reinvention Hypotheses. Candidate additions are explicitly marked for future acceptance.
