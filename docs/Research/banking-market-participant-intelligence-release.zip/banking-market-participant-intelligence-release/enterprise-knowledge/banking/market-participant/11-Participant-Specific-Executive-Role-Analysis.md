# Participant-Specific Executive-Role Analysis

**Asset ID:** `EK-BANK-MPI-001-EXE`  
**Effective date:** 2026-07-19  
**Governance:** Roles are inferred from evidenced mechanisms and participant pressures. No individual names are used.

| Participant ID | Participant | Executive roles likely to care | Why these roles matter | Unknowns |
|---|---|---|---|---|
| `BK-MP-001` | Lloyds Banking Group | CEO; CFO; Retail Banking Director; COO; CIO/CTO; CRO; Customer/Distribution leader; Transformation leader | Mechanism exposure: BM-01, BM-06, BM-07, BM-10, BM-15, BM-16, BM-17, BM-20 | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-002` | NatWest Group | CEO; Commercial Banking / C&I leader; COO; CIO/CTO; Chief Data/AI; CRO; Relationship banking leadership | Mechanism exposure: BM-03, BM-05, BM-06, BM-12, BM-17, BM-20 | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-003` | Barclays | CEO; CFO; CRO; Investment Bank leadership; UK retail/corporate leadership; Treasury; COO; CIO/CTO | Mechanism exposure: BM-10 plus Barclays candidate mechanisms; BM-01, BM-05, BM-06 where retail/commercial apply | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-004` | Santander UK | Santander UK CEO/Board roles; Banco Santander group platform/technology leadership; CFO; COO; CIO/CTO; Risk; Integration leader | Mechanism exposure: BM-06, BM-08, BM-10, BM-16, BM-19, BM-22 | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-005` | Nationwide / Virgin Money | CEO; CFO; Member/Customer leadership; Distribution/Branch leadership; COO; CIO/CTO; Risk; Integration leader | Mechanism exposure: BM-02, BM-04, BM-06, BM-08, BM-10, BM-15, BM-16 | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-006` | Monzo | CEO; COO; Product; Customer Operations; Risk/Financial Crime; CTO; Data/AI; Finance/Treasury | Mechanism exposure: BM-01, BM-03, BM-06, BM-09, BM-11, BM-12, BM-16, BM-19 | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-007` | Starling Bank | CEO; Business Banking; Platform/Engine leadership; COO; CTO; Risk/Financial Crime; Customer Operations | Mechanism exposure: BM-03, BM-05, BM-06, BM-11, BM-12, BM-16, BM-19, BM-22 | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-008` | Pay.UK / UK retail payments infrastructure | Infrastructure CEO/COO; Technology/Operations; Risk/Resilience; Policy/Regulatory engagement; Scheme/overlay leadership | Mechanism exposure: BM-11, BM-13, BM-18 | Unknown: named individuals, decision rights and current sponsorship are not established. |
| `BK-MP-009` | Critical third-party cloud and AI providers | Bank-side CIO/CTO; CISO; CRO; Procurement/Supplier management; Data/AI; Operational resilience; Provider account/regulatory leads | Mechanism exposure: BM-16, BM-17, BM-19, BM-20, BM-13 | Unknown: named individuals, decision rights and current sponsorship are not established. |

## Role interpretation controls

- Role relevance is not evidence of sponsorship.
- Executive pressure is not evidence of budget or route-to-market.
- Named individuals require current source evidence and governance permission.
- Commercial accessibility remains separate from enterprise need.
