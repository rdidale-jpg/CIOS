# Competitor Move Records

**Asset ID:** `EK-BANK-MPI-001-MOVE`  
**Effective date:** 2026-07-19  
**Scope:** Evidence-backed participant and ecosystem moves. Corporate messaging is not treated as demonstrated change unless supported by governed assets.


---

## BK-MOVE-001

```yaml
move_id: BK-MOVE-001
participant_id: BK-MP-005
move_summary: Branch commitment / member-value access posture
move_type: branch commitment
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Nationwide’s branch model is preserved as a trust and member-value variant rather than treated only as a cost burden.
affected_mechanisms: [BM-02; BM-04; BM-10]
affected_hypotheses: [BRH-003; BRH-013]
competitive_effect: Creates access/trust differentiation pressure on branch-rationalising incumbents and digital-only challengers.
commercial_implications: Candidate commercial interpretation: assisted-access, service-model sustainability and member-value evidence may matter.
source_ids: [ENT-NWVM-003; BANK-TWIN-001; BK-MPI-OBS-003]
confidence: High
unknowns: Long-term economics and integration impact unknown.
contradictions: Branch trust and branch cost are not mutually exclusive; participant type determines interpretation.
```

---

## BK-MOVE-002

```yaml
move_id: BK-MOVE-002
participant_id: BK-MP-006
move_summary: Active-user primary-bank conversion
move_type: app-first migration
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Monzo reports a large active-user primary-bank signal but not majority primacy across registered users.
affected_mechanisms: [BM-01; BM-03; BM-06]
affected_hypotheses: [BRH-001; BRH-010]
competitive_effect: Pressures incumbent primacy and deposit acquisition models while leaving durability unknown.
commercial_implications: Commercial relevance may exist around primacy analytics, deposit depth, fraud/control and assisted access, but account evidence is missing.
source_ids: [ENT-MONZO-004; BANK-TWIN-001; BK-MPI-OBS-004]
confidence: High
unknowns: Salary-flow/direct-debit/cross-product depth unknown.
contradictions: High app engagement does not equal whole-base primacy.
```

---

## BK-MOVE-003

```yaml
move_id: BK-MOVE-003
participant_id: BK-MP-007
move_summary: SME-weighted platform challenger and Engine export
move_type: ecosystem partnership / platform renewal
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Starling combines SME banking with platform export characteristics through Engine.
affected_mechanisms: [BM-05; BM-16; BM-22]
affected_hypotheses: [BRH-004; BRH-010]
competitive_effect: Pressures commercial incumbents and technology providers by making banking-platform capability visible as a market participant behaviour.
commercial_implications: Commercial relevance may exist around SME workflow, platform assurance, partner execution and financial-crime maturity.
source_ids: [ENT-STAR-005; BANK-TWIN-001; BK-MPI-OBS-005]
confidence: High
unknowns: Engine adoption economics and exact client outcomes unknown.
contradictions: Low legacy does not remove regulatory remediation obligations.
```

---

## BK-MOVE-004

```yaml
move_id: BK-MOVE-004
participant_id: BK-MP-002
move_summary: Relationship-bank AI and API posture
move_type: customer-outcome programme / platform renewal
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: NatWest validates a commercial relationship-bank model combining C&I, Bankline/API, RMs, AI and cloud/data investment.
affected_mechanisms: [BM-05; BM-17; BM-20]
affected_hypotheses: [BRH-004; BRH-007]
competitive_effect: Creates pressure on peers where commercial banking remains product-led or where RM productivity is less digitally augmented.
commercial_implications: Commercial relevance may exist around relationship-data platforms and KYB/customer outcome evidence; commercial route is not established.
source_ids: [ENT-NTW-002; BANK-TWIN-001; BK-MPI-OBS-002]
confidence: High
unknowns: Realised AI relationship outcomes unknown.
contradictions: AI may be relationship augmentation rather than only back-office productivity.
```

---

## BK-MOVE-005

```yaml
move_id: BK-MOVE-005
participant_id: BK-MP-001
move_summary: Scale-incumbent simplification and mobile-first defence
move_type: channel simplification / cost transformation
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Lloyds uses deposit/current-account scale, structural hedge/NII, capital and simplification to fund transformation and defend primacy.
affected_mechanisms: [BM-01; BM-07; BM-15; BM-16]
affected_hypotheses: [BRH-001; BRH-009]
competitive_effect: Pressures other scale participants to prove investment capacity and operating leverage.
commercial_implications: Commercial relevance may exist around cloud/core migration, AI control and customer outcome evidence; route is unknown.
source_ids: [ENT-LBG-001; BK-MPI-OBS-001]
confidence: High
unknowns: Renewed primacy proof remains partial.
contradictions: Strong economic loop does not prove customer primacy strengthening.
```

---

## BK-MOVE-006

```yaml
move_id: BK-MOVE-006
participant_id: BK-MP-004
move_summary: Santander UK TSB acquisition under global platform ambition
move_type: cost transformation / platform renewal
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Santander UK acquisition of TSB is a live test of local integration risk under global platform-owner ambition.
affected_mechanisms: [BM-10; BM-15; BM-16; BM-19; BM-22]
affected_hypotheses: [BRH-011; BRH-008]
competitive_effect: Creates integration and local/global accountability pressure compared with UK-headquartered incumbents.
commercial_implications: Commercial relevance may exist around integration, data, migration, platform governance and outcome evidence; ownership and route unknown.
source_ids: [ENT-SAN-007; BANK-TWIN-001; BK-MPI-OBS-007; BK-MPI-OBS-011]
confidence: High
unknowns: Realised synergies and migration outcomes unknown.
contradictions: Global platform acceleration can coexist with local accountability risk.
```

---

## BK-MOVE-007

```yaml
move_id: BK-MOVE-007
participant_id: BK-MP-003
move_summary: Universal-bank portfolio and investment-bank candidate mechanisms
move_type: strategic repositioning
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Barclays adds universal-bank and capital-markets dynamics to the Banking model, beyond retail/commercial mechanisms.
affected_mechanisms: [BM-10 plus candidate capital-markets mechanisms]
affected_hypotheses: [BRH-012]
competitive_effect: Creates comparison pressure because retail/commercial-only views cannot explain Barclays capital/RWA dynamics.
commercial_implications: Commercial relevance may exist around data, risk, control, platform and capital-portfolio visibility; canonical mechanism status remains candidate.
source_ids: [ENT-BARC-006; BANK-TWIN-001; BK-MPI-OBS-006]
confidence: High
unknowns: Candidate mechanisms not yet accepted as canonical.
contradictions: One Twin can model Barclays, but BM catalogue may need future extension.
```

---

## BK-MOVE-008

```yaml
move_id: BK-MOVE-008
participant_id: BK-MP-008
move_summary: Infrastructure control-boundary assertion
move_type: shared infrastructure / access-model innovation
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Payments infrastructure controls reachability, rules, settlement and interoperability while banks own customer channels and account state.
affected_mechanisms: [BM-11; BM-13; BM-18]
affected_hypotheses: [BRH-005; BRH-006]
competitive_effect: Creates pressure on all banks by limiting what bank-local transformation can control.
commercial_implications: Commercial relevance may exist where bank journeys depend on shared rail/overlay readiness and rules; must not be misattributed to banks alone.
source_ids: [BANK-INFRA-001; BK-MPI-OBS-008]
confidence: High
unknowns: Future infrastructure transition timing and commercial model unknown.
contradictions: Bank strategy may be constrained by infrastructure even where bank UX is strong.
```

---

## BK-MOVE-009

```yaml
move_id: BK-MOVE-009
participant_id: BK-MP-009
move_summary: Critical third-party cloud and AI dependency becomes participant-level market force
move_type: platform renewal / resilience
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Cloud and AI providers become regulated operating-model dependencies, not neutral suppliers.
affected_mechanisms: [BM-16; BM-17; BM-19; BM-20]
affected_hypotheses: [BRH-007; BRH-008]
competitive_effect: Creates pressure on banks to evidence workload control, exit strategy, resilience and model governance.
commercial_implications: Commercial relevance may exist around assurance, portability, service continuity and data/AI governance, subject to account evidence.
source_ids: [BANK-FOUND-001; BANK-INFRA-001; BK-MPI-OBS-009]
confidence: Medium
unknowns: Bank-by-bank exposure maps unknown.
contradictions: Cloud accelerates capability while concentrating systemic dependency.
```

---

## BK-MOVE-010

```yaml
move_id: BK-MOVE-010
participant_id: BK-MP-006; BK-MP-007
move_summary: Digital challenger control maturity becomes visible competitive condition
move_type: trust or inclusion positioning / customer-outcome programme
date_or_period: Governed source window 2025-2026 unless source Twin states narrower period.
why_it_matters: Challenger growth is accompanied by AML, APP fraud, financial-crime, capital and regulatory maturity pressure.
affected_mechanisms: [BM-11; BM-12; BM-13; BM-10]
affected_hypotheses: [BRH-006; BRH-010; BRH-014]
competitive_effect: Incumbents can compete on trust/control while challengers compete on engagement and service.
commercial_implications: Commercial relevance may exist around control evidence, fraud operations and resilient service design; no participant ranking supported.
source_ids: [ENT-MONZO-004; ENT-STAR-005; BK-MPI-OBS-010]
confidence: High
unknowns: Current internal control remediation effectiveness unknown.
contradictions: Digital growth does not eliminate banking control burden.
```
