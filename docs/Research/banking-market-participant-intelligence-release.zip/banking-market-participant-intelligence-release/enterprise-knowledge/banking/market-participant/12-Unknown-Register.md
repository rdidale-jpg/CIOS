# Unknown Register

**Asset ID:** `EK-BANK-MPI-001-UNK`  
**Effective date:** 2026-07-19

| Unknown ID | Participant | What is Unknown | Why it matters | Evidence required | Research priority |
|---|---|---|---|---|---|
| BK-UNK-001 | BK-MP-001 | Salary-flow and direct-debit concentration that would prove renewed current-account primacy. | Constrains primacy and deposit-depth judgement. | Lloyds transaction-flow, salary and direct-debit evidence. | High |
| BK-UNK-002 | BK-MP-001 | Supplier workshare and procurement route for simplification, cloud, AI and customer-outcome programmes. | Constrains commercial accessibility. | Contracts/procurement/account evidence. | High |
| BK-UNK-003 | BK-MP-002 | Realised AI outcome evidence in relationship banking. | Constrains AI relationship-bank opportunity interpretation. | Operational KPIs, benefit realisation evidence, internal use-case records. | High |
| BK-UNK-004 | BK-MP-002 | KYB and relationship-data platform ownership and current programme status. | Constrains SME/commercial workflow interpretation. | Programme and architecture evidence. | High |
| BK-UNK-005 | BK-MP-003 | Accepted canonical status of Barclays capital-markets mechanisms. | Constrains mechanism catalogue and participant comparison. | Further Barclays deepening and mechanism acceptance. | Medium |
| BK-UNK-006 | BK-MP-003 | Investment-bank technology/platform and supplier boundaries relevant to UK Banking commercial implications. | Constrains commercial seam identification. | Supplier/platform/procurement evidence. | Medium |
| BK-UNK-007 | BK-MP-004 | TSB integration realised synergies, migration sequence and customer-outcome evidence. | Constrains Santander integration whitespace. | Santander UK/TSB integration updates and KPIs. | High |
| BK-UNK-008 | BK-MP-004 | Local UK versus Banco Santander group decision rights over target platforms and AI/data model. | Constrains route and accountability interpretation. | Governance, architecture and programme evidence. | High |
| BK-UNK-009 | BK-MP-005 | Long-term branch promise economics after Virgin Money integration. | Constrains branch trust/access whitespace. | Branch usage, costs, customer outcome and integration evidence. | High |
| BK-UNK-010 | BK-MP-005 | Realised Virgin Money integration benefits and platform decommissioning sequence. | Constrains integration and transformation interpretation. | Integration programme evidence and benefits reporting. | High |
| BK-UNK-011 | BK-MP-006 | Salary-flow, direct-debit, benefit/pension flow and cohort-level product depth for Monzo customers. | Constrains primacy judgement. | Monzo cohort/account-flow evidence. | High |
| BK-UNK-012 | BK-MP-006 | Internal financial-crime, APP and control maturity after scale growth. | Constrains trust/control judgement. | Regulatory, audit, operational and performance evidence. | High |
| BK-UNK-013 | BK-MP-007 | Engine revenue durability, external client adoption and target customer economics. | Constrains platform-export interpretation. | Engine customer and financial evidence. | Medium |
| BK-UNK-014 | BK-MP-007 | Current remediation and financial-crime control maturity evidence. | Constrains trust/control and growth interpretation. | Regulatory/operational updates. | High |
| BK-UNK-015 | BK-MP-008 | Future retail payment infrastructure operating model and timeline. | Constrains infrastructure transition whitespace. | RPIB/Pay.UK/BoE/PSR updates. | High |
| BK-UNK-016 | BK-MP-008 | Vocalink/central infrastructure contract or ownership outcome and consequence for participants. | Constrains infrastructure dependency judgement. | Contract/operator evidence. | Medium |
| BK-UNK-017 | BK-MP-009 | Bank-by-bank cloud workload maps, exit strategy and concentration exposure. | Constrains technology participant role and bank exposure. | Operational resilience, CTP and procurement evidence. | High |
| BK-UNK-018 | All participants | Participant-specific Consumer Duty and outcome-evidence operating models. | Constrains outcome-evidence whitespace and executive role mapping. | Outcome MI, regulatory updates, complaints/service/fraud evidence. | High |
| BK-UNK-019 | All participants | Current account-access, procurement route and relationship access. | Constrains all commercial interpretation. | Human-supplied account knowledge and procurement evidence. | High |
| BK-UNK-020 | All participants | Which programmes are already funded, contracted or incumbent-owned. | Constrains commercial opening vs occupied space. | Programme, supplier, award and procurement evidence. | High |
