# Codex Implementation Handoff

**Asset ID:** `EK-BANK-MPI-001-CODEX`  
**Effective date:** 2026-07-19  
**Purpose:** Allow a later Codex implementation to consume governed participant intelligence without inventing missing knowledge.

## Implementation boundary

Codex may build data structures, references, filters, comparison views and provenance-aware retrieval over this asset. Codex must not create runtime ranking logic, infer missing commercial accessibility, invent programme ownership or convert whitespace into recommendations.

## Structured handoff

```json
{
  "asset_id": "EK-BANK-MPI-001-CODEX",
  "status": "candidate_handoff",
  "safe_for_runtime_use": [
    "participant_id",
    "participant_name",
    "participant_type",
    "coverage_status",
    "qualitative_relevance",
    "supporting_observation_ids",
    "mechanism_ids",
    "hypothesis_ids",
    "confidence",
    "unknown_ids",
    "contradiction_ids",
    "freshness_status",
    "evidence_source_ids",
    "recommended_ui_label"
  ],
  "fields_requiring_further_research": [
    "commercial_accessibility",
    "relationship_access",
    "procurement_route",
    "named_executive_sponsor",
    "programme_budget",
    "supplier_workshare",
    "cloud_workload_map",
    "active procurement status",
    "account priority"
  ],
  "fields_unsuitable_for_ranking": [
    "participant_type",
    "evidence_strength",
    "qualitative_relevance",
    "whitespace proposition",
    "competitor pressure",
    "executive role inference"
  ],
  "do_not_build": [
    "automated participant ranking",
    "numeric opportunity score",
    "sales priority model",
    "CRM integration",
    "opportunity cards presented as fact",
    "implementation recommendation engine"
  ],
  "participants": [
    {
      "participant_id": "BK-MP-001",
      "participant_name": "Lloyds Banking Group",
      "participant_type": "Large retail incumbent / scale retail incumbent",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 1 core",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-005, BK-OBS-006, BK-OBS-008, BK-OBS-014, BK-OBS-032, BK-OBS-033"
      ],
      "mechanism_ids": [
        "BM-01, BM-06, BM-07, BM-10, BM-15, BM-16, BM-17, BM-20"
      ],
      "hypothesis_ids": [
        "BRH-001, BRH-002, BRH-007, BRH-009, BRH-014"
      ],
      "confidence": "High for scale incumbent economics; Medium for primacy renewal and specific commercial accessibility.",
      "recommended_ui_label": "Lloyds Banking Group \u2014 Large retail incumbent"
    },
    {
      "participant_id": "BK-MP-002",
      "participant_name": "NatWest Group",
      "participant_type": "UK commercial incumbent / relationship bank",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 2 incumbent comparison",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-003, BK-OBS-034, BK-OBS-037, BK-OBS-042"
      ],
      "mechanism_ids": [
        "BM-03, BM-05, BM-06, BM-12, BM-17, BM-20"
      ],
      "hypothesis_ids": [
        "BRH-004, BRH-007, BRH-009, BRH-014"
      ],
      "confidence": "High for commercial-relationship variant; Medium for AI outcome maturity and route/access.",
      "recommended_ui_label": "NatWest Group \u2014 UK commercial incumbent"
    },
    {
      "participant_id": "BK-MP-003",
      "participant_name": "Barclays",
      "participant_type": "Universal bank",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 2 incumbent comparison",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-030, BK-OBS-039, BK-OBS-042"
      ],
      "mechanism_ids": [
        "BM-10 plus Barclays candidate mechanisms",
        "BM-01, BM-05, BM-06 where retail/commercial apply"
      ],
      "hypothesis_ids": [
        "BRH-012, BRH-010, BRH-007"
      ],
      "confidence": "High for need to model universal-bank variant; Medium for candidate mechanism completeness.",
      "recommended_ui_label": "Barclays \u2014 Universal bank"
    },
    {
      "participant_id": "BK-MP-004",
      "participant_name": "Santander UK",
      "participant_type": "Multinational platform-bank subsidiary / UK ring-fenced bank",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 2 incumbent comparison",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-031, BK-OBS-043, BK-OBS-050"
      ],
      "mechanism_ids": [
        "BM-06, BM-08, BM-10, BM-16, BM-19, BM-22"
      ],
      "hypothesis_ids": [
        "BRH-008, BRH-011, BRH-010, BRH-014"
      ],
      "confidence": "High for global-platform/local-accountability variant; Medium for TSB integration outcome.",
      "recommended_ui_label": "Santander UK \u2014 Multinational platform-bank subsidiary"
    },
    {
      "participant_id": "BK-MP-005",
      "participant_name": "Nationwide / Virgin Money",
      "participant_type": "Mutual or member-owned bank / building society with acquired bank integration",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 1 core",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-009, BK-OBS-029, BK-OBS-043, BK-OBS-047"
      ],
      "mechanism_ids": [
        "BM-02, BM-04, BM-06, BM-08, BM-10, BM-15, BM-16"
      ],
      "hypothesis_ids": [
        "BRH-003, BRH-011, BRH-013, BRH-014"
      ],
      "confidence": "High for mutual/branch-trust variant; Medium for acquisition-integration outcomes.",
      "recommended_ui_label": "Nationwide / Virgin Money \u2014 Mutual or member-owned bank"
    },
    {
      "participant_id": "BK-MP-006",
      "participant_name": "Monzo",
      "participant_type": "Digital-native consumer challenger",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 1 core",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-012, BK-OBS-013, BK-OBS-027, BK-OBS-049"
      ],
      "mechanism_ids": [
        "BM-01, BM-03, BM-06, BM-09, BM-11, BM-12, BM-16, BM-19"
      ],
      "hypothesis_ids": [
        "BRH-001, BRH-002, BRH-006, BRH-010"
      ],
      "confidence": "High for digital engagement/active-user conversion; Medium for durable majority primacy and lending economics.",
      "recommended_ui_label": "Monzo \u2014 Digital-native consumer challenger"
    },
    {
      "participant_id": "BK-MP-007",
      "participant_name": "Starling Bank",
      "participant_type": "Digital-native SME/platform challenger",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 3 challenger/ecosystem extension",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-028, BK-OBS-049, BK-OBS-020, BK-OBS-018"
      ],
      "mechanism_ids": [
        "BM-03, BM-05, BM-06, BM-11, BM-12, BM-16, BM-19, BM-22"
      ],
      "hypothesis_ids": [
        "BRH-004, BRH-007, BRH-008, BRH-010"
      ],
      "confidence": "High for SME/platform challenger variant; Medium for external platform economics.",
      "recommended_ui_label": "Starling Bank \u2014 Digital-native SME"
    },
    {
      "participant_id": "BK-MP-008",
      "participant_name": "Pay.UK / UK retail payments infrastructure",
      "participant_type": "Banking infrastructure participant",
      "coverage_status": "Meaningful governed coverage \u2014 Wave 1 infrastructure participant",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-021, BK-OBS-022, BK-OBS-023, BK-OBS-024, BK-OBS-025"
      ],
      "mechanism_ids": [
        "BM-11, BM-13, BM-18"
      ],
      "hypothesis_ids": [
        "BRH-005, BRH-006, BRH-003"
      ],
      "confidence": "High for control-boundary model; Medium for transition/ownership outcomes.",
      "recommended_ui_label": "Pay.UK / UK retail payments infrastructure \u2014 Banking infrastructure participant"
    },
    {
      "participant_id": "BK-MP-009",
      "participant_name": "Critical third-party cloud and AI providers",
      "participant_type": "Technology/platform/service participant cohort",
      "coverage_status": "Partial governed coverage \u2014 Wave 3 technology participant, cohort-level not full provider Twin",
      "comparable_attributes": [
        "ownership_model",
        "market_role",
        "distribution_model",
        "strategic_position",
        "transformation_pressures",
        "technology_constraints",
        "relevant_mechanisms",
        "relevant_observations",
        "relevant_hypotheses",
        "evidence_strength",
        "freshness",
        "unknowns",
        "contradictions"
      ],
      "supporting_observation_ids": [
        "BK-OBS-017, BK-OBS-018, BK-OBS-045, BK-OBS-048"
      ],
      "mechanism_ids": [
        "BM-16, BM-17, BM-19, BM-20, BM-13"
      ],
      "hypothesis_ids": [
        "BRH-007, BRH-008, BRH-014"
      ],
      "confidence": "Medium: role is strongly evidenced; individual provider-by-bank exposure is not.",
      "recommended_ui_label": "Critical third-party cloud and AI providers \u2014 Technology"
    }
  ]
}
```

## Relationship record pointers

- Competitive relationships: `07-Competitive-Relationship-Records.md`
- Competitor moves: `06-Competitor-Move-Records.md`
- Opportunity relevance assessments: `09-Opportunity-to-Participant-Analysis.md`
- Unknowns: `12-Unknown-Register.md`
- Contradictions: `13-Contradiction-Register.md`

## Recommended UI labels

| Participant ID | UI label |
|---|---|
| `BK-MP-001` | Lloyds Banking Group — Large retail incumbent |
| `BK-MP-002` | NatWest Group — UK commercial incumbent |
| `BK-MP-003` | Barclays — Universal bank |
| `BK-MP-004` | Santander UK — Multinational platform-bank subsidiary |
| `BK-MP-005` | Nationwide / Virgin Money — Mutual or member-owned bank |
| `BK-MP-006` | Monzo — Digital-native consumer challenger |
| `BK-MP-007` | Starling Bank — Digital-native SME |
| `BK-MP-008` | Pay.UK / UK retail payments infrastructure — Banking infrastructure participant |
| `BK-MP-009` | Critical third-party cloud and AI providers — Technology |

## Runtime safety rules

1. Display confidence and Unknowns alongside every participant implication.
2. Do not sort participants by commercial priority unless a separate accepted scoring model exists.
3. Do not show whitespace as a recommendation.
4. Do not imply named executive ownership.
5. Do not merge infrastructure-owned and bank-owned mechanisms.
6. Preserve cross-reference IDs so every statement can route back to evidence.
