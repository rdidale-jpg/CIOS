# Initial Banking Participant Cohort

**Asset ID:** `EK-BANK-MPI-001-COHORT`  
**Effective date:** 2026-07-19

## Selection logic

The cohort is deliberately contrasting rather than exhaustive. It tests whether Flora can compare participants across ownership, scale, distribution, balance-sheet model, technology posture, infrastructure control and ecosystem dependency.

| Participant ID | Participant | Type | Coverage status | Primary evidence | Confidence |
|---|---|---|---|---|---|
| `BK-MP-001` | Lloyds Banking Group | Large retail incumbent / scale retail incumbent | Meaningful governed coverage — Wave 1 core | BK-OBS-005, BK-OBS-006, BK-OBS-008, BK-OBS-014, BK-OBS-032, BK-OBS-033 | High for scale incumbent economics; Medium for primacy renewal and specific commercial accessibility. |
| `BK-MP-002` | NatWest Group | UK commercial incumbent / relationship bank | Meaningful governed coverage — Wave 2 incumbent comparison | BK-OBS-003, BK-OBS-034, BK-OBS-037, BK-OBS-042 | High for commercial-relationship variant; Medium for AI outcome maturity and route/access. |
| `BK-MP-003` | Barclays | Universal bank | Meaningful governed coverage — Wave 2 incumbent comparison | BK-OBS-030, BK-OBS-039, BK-OBS-042 | High for need to model universal-bank variant; Medium for candidate mechanism completeness. |
| `BK-MP-004` | Santander UK | Multinational platform-bank subsidiary / UK ring-fenced bank | Meaningful governed coverage — Wave 2 incumbent comparison | BK-OBS-031, BK-OBS-043, BK-OBS-050 | High for global-platform/local-accountability variant; Medium for TSB integration outcome. |
| `BK-MP-005` | Nationwide / Virgin Money | Mutual or member-owned bank / building society with acquired bank integration | Meaningful governed coverage — Wave 1 core | BK-OBS-009, BK-OBS-029, BK-OBS-043, BK-OBS-047 | High for mutual/branch-trust variant; Medium for acquisition-integration outcomes. |
| `BK-MP-006` | Monzo | Digital-native consumer challenger | Meaningful governed coverage — Wave 1 core | BK-OBS-012, BK-OBS-013, BK-OBS-027, BK-OBS-049 | High for digital engagement/active-user conversion; Medium for durable majority primacy and lending economics. |
| `BK-MP-007` | Starling Bank | Digital-native SME/platform challenger | Meaningful governed coverage — Wave 3 challenger/ecosystem extension | BK-OBS-028, BK-OBS-049, BK-OBS-020, BK-OBS-018 | High for SME/platform challenger variant; Medium for external platform economics. |
| `BK-MP-008` | Pay.UK / UK retail payments infrastructure | Banking infrastructure participant | Meaningful governed coverage — Wave 1 infrastructure participant | BK-OBS-021, BK-OBS-022, BK-OBS-023, BK-OBS-024, BK-OBS-025 | High for control-boundary model; Medium for transition/ownership outcomes. |
| `BK-MP-009` | Critical third-party cloud and AI providers | Technology/platform/service participant cohort | Partial governed coverage — Wave 3 technology participant, cohort-level not full provider Twin | BK-OBS-017, BK-OBS-018, BK-OBS-045, BK-OBS-048 | Medium: role is strongly evidenced; individual provider-by-bank exposure is not. |

## Participant type framework

| Participant type | Strategic exposure | Operating-model pressure | Likely executive concerns | Commercial implication boundary |
|---|---|---|---|---|
| Large retail incumbent | Defending primary current account, deposits, mortgage scale, trust and cost-to-income | Legacy simplification, channel migration, branch/access trade-off | CEO, CFO, Retail, COO, CIO/CTO, Risk, Customer | Relevant only where participant-specific mechanism exposure and access route are evidenced |
| UK commercial incumbent | Deepening commercial relationships and relationship-data advantage | KYB, RM productivity, API/data platforms, C&I economics | CEO, Commercial Banking, COO, CIO/CTO, Risk, Data/AI | Relationship-data, workflow, AI and KYB seams require evidence of ownership and route |
| Universal bank | Balancing retail/commercial stability with capital-markets volatility | Capital/RWA allocation across trading, IB, cards, wealth and retail | CEO, CFO, CRO, IB leadership, Treasury, COO, CIO/CTO | Retail/commercial seams must not be confused with capital-markets candidate mechanisms |
| Mutual / member-owned | Member trust, branch/community access, mortgage/savings economics | Surplus allocation between capital, member value, branches, transformation and integration | CEO, CFO, Member/Customer, Distribution, COO, CIO/CTO, Risk | Commercial interpretation must preserve member-value logic, not shareholder-only economics |
| Digital consumer challenger | Primary conversion, active engagement, deposit/product depth | Growth control, fraud/AML, lending discipline, capital maturity, cloud dependency | CEO, COO, Product, Risk, CTO, Customer Operations, Finance | Strong relevance where digital primacy/growth-control evidence exists; no assumption of majority primacy |
| Digital SME/platform challenger | SME workflows, deposits, platform export | Financial-crime maturity, platform resilience, SME workflow integration, cloud dependency | CEO, Business Banking, COO, CTO, Risk, Platform/Engine leadership | Platform and SME workflow seams are candidate interpretations unless commercial route is evidenced |
| Banking infrastructure participant | Rail availability, rules, settlement, interoperability and overlay services | Industry rule change, resilience, access, transition-state management | Infrastructure CEO/COO, Operations, Risk, Technology, Policy | Commercial relevance must separate bank-owned from infrastructure-owned mechanisms |
| Technology/platform/service participant | Cloud, AI, data and resilience dependency | Concentration, exit, assurance, workload portability, regulatory oversight | Bank CIO/CTO, CISO, Risk, Procurement, Data/AI | Provider role is context unless exact bank dependency, route and scope are evidenced |

## Analytical control

Generic `competes_with` relationships are prohibited. A relationship must be tied to a mechanism, observation, hypothesis, competitor move or control boundary.
