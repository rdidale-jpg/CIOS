# New Banking Participant Observations

**Asset ID:** `EK-BANK-MPI-001-OBS`  
**Effective date:** 2026-07-19  
**Status:** Candidate participant-intelligence observations for owner review.  
**Important:** These do not overwrite `BANK-OBS-001`. Promote to the canonical Banking Observation Register only after acceptance.

## Observation creation rule

Each observation is one evidence-backed participant/comparison condition. Static background is excluded unless commercially material.


---

## BK-MPI-OBS-001

**Observation statement:** Lloyds is the scale incumbent reference case for a deposit/current-account, structural hedge and reinvestment-capacity loop, while renewed primacy remains only partially evidenced.

| Field | Value |
|---|---|
| Observation type | Commercial |
| Affected participant | BK-MP-001 |
| Evidence | ENT-LBG-001; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-005; BK-OBS-006; BK-OBS-008 |
| Related mechanisms | BM-01; BM-06; BM-07; BM-10 |
| Related hypotheses | BRH-001; BRH-002; BRH-009 |
| Confidence | High for loop; Medium for primacy renewal |
| Unknowns | Salary-flow, direct-debit concentration and durable challenger displacement evidence. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-002

**Observation statement:** NatWest is the clearest governed commercial-incumbent variant where relationship managers, deposits, payments, APIs, AI and cloud/data investment combine into a relationship-bank model.

| Field | Value |
|---|---|
| Observation type | Commercial |
| Affected participant | BK-MP-002 |
| Evidence | ENT-NTW-002; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-034; BK-OBS-042 |
| Related mechanisms | BM-05; BM-17; BM-20 |
| Related hypotheses | BRH-004; BRH-007 |
| Confidence | High |
| Unknowns | Exact realised AI outcome evidence and route-to-market remain unknown. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-003

**Observation statement:** Nationwide treats branches as member-value and trust infrastructure, not only as a distribution cost burden.

| Field | Value |
|---|---|
| Observation type | Relationship |
| Affected participant | BK-MP-005 |
| Evidence | ENT-NWVM-003; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-029; BK-OBS-047 |
| Related mechanisms | BM-02; BM-04; BM-10 |
| Related hypotheses | BRH-003; BRH-013 |
| Confidence | High |
| Unknowns | Long-term economics of branch commitment after Virgin Money integration remain unknown. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-004

**Observation statement:** Monzo’s strongest public primacy signal is active-user based and does not prove majority primacy across all registered customers.

| Field | Value |
|---|---|
| Observation type | Commercial |
| Affected participant | BK-MP-006 |
| Evidence | ENT-MONZO-004; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-013; BK-OBS-027 |
| Related mechanisms | BM-01; BM-03; BM-06 |
| Related hypotheses | BRH-001; BRH-010 |
| Confidence | High |
| Unknowns | Salary-flow, direct-debit share and cohort-level balance/product depth remain unknown. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-005

**Observation statement:** Starling validates a distinct SME-weighted challenger model combining profitable deposit-funded banking with platform-export characteristics.

| Field | Value |
|---|---|
| Observation type | Competitive |
| Affected participant | BK-MP-007 |
| Evidence | ENT-STAR-005; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-028 |
| Related mechanisms | BM-05; BM-22; BM-16 |
| Related hypotheses | BRH-004; BRH-010 |
| Confidence | High |
| Unknowns | Engine revenue durability and external platform adoption evidence remain incomplete. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-006

**Observation statement:** Barclays cannot be fully interpreted through retail/commercial banking mechanisms because its universal-bank model introduces capital-markets candidate mechanisms.

| Field | Value |
|---|---|
| Observation type | Structural |
| Affected participant | BK-MP-003 |
| Evidence | ENT-BARC-006; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-030; BK-OBS-039 |
| Related mechanisms | BM-10 plus Barclays candidates |
| Related hypotheses | BRH-012 |
| Confidence | High |
| Unknowns | Canonical status of investment-bank mechanisms remains candidate. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-007

**Observation statement:** Santander UK combines local ring-fenced accountability with Banco Santander global platform, technology, AI and operating-model influence.

| Field | Value |
|---|---|
| Observation type | Structural |
| Affected participant | BK-MP-004 |
| Evidence | ENT-SAN-007; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-031; BK-OBS-050 |
| Related mechanisms | BM-16; BM-19; BM-10; BM-22 |
| Related hypotheses | BRH-008; BRH-011 |
| Confidence | High |
| Unknowns | TSB integration outcomes and local/global decision rights need refresh. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-008

**Observation statement:** Pay.UK and the wider payments infrastructure own or shape reachability, settlement, rules, overlay services and transition-state constraints that individual banks cannot control alone.

| Field | Value |
|---|---|
| Observation type | Infrastructure |
| Affected participant | BK-MP-008 |
| Evidence | BANK-INFRA-001; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-021; BK-OBS-022; BK-OBS-023; BK-OBS-024; BK-OBS-025 |
| Related mechanisms | BM-11; BM-13; BM-18 |
| Related hypotheses | BRH-005; BRH-006 |
| Confidence | High |
| Unknowns | Future retail payment infrastructure and contractual/operator changes require refresh. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-009

**Observation statement:** Critical third-party cloud and AI providers are commercially relevant market participants because governed Banking assets treat cloud and AI dependency as part of the regulated operating model.

| Field | Value |
|---|---|
| Observation type | Technological |
| Affected participant | BK-MP-009 |
| Evidence | BANK-FOUND-001; BANK-INFRA-001; BANK-OBS-001 |
| Supporting governed observations | BK-OBS-017; BK-OBS-018; BK-OBS-045; BK-OBS-048 |
| Related mechanisms | BM-16; BM-17; BM-19; BM-20 |
| Related hypotheses | BRH-007; BRH-008 |
| Confidence | Medium |
| Unknowns | Individual provider-by-bank workload maps, exit plans and contract boundaries remain unknown. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-010

**Observation statement:** Digital challenger growth creates control-maturity pressure rather than eliminating regulated-bank obligations.

| Field | Value |
|---|---|
| Observation type | Risk |
| Affected participant | BK-MP-006; BK-MP-007 |
| Evidence | ENT-MONZO-004; ENT-STAR-005; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-049; BK-OBS-036; BK-OBS-037 |
| Related mechanisms | BM-11; BM-12; BM-13 |
| Related hypotheses | BRH-006; BRH-010 |
| Confidence | High |
| Unknowns | Current internal control maturity and post-remediation effectiveness remain unknown. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-011

**Observation statement:** Bank acquisitions are visible reinvention tests in the current Banking evidence base, especially Nationwide/Virgin Money and Santander/TSB.

| Field | Value |
|---|---|
| Observation type | Structural |
| Affected participant | BK-MP-004; BK-MP-005 |
| Evidence | ENT-NWVM-003; ENT-SAN-007; BANK-TWIN-001 |
| Supporting governed observations | BK-OBS-043 |
| Related mechanisms | BM-15; BM-16; BM-10; BM-22 |
| Related hypotheses | BRH-011 |
| Confidence | High for existence; Medium for outcomes |
| Unknowns | Realised integration benefits, platform sequence and customer migration outcomes remain unknown. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |

---

## BK-MPI-OBS-012

**Observation statement:** Participant type materially changes opportunity interpretation; the same access, AI, cloud or payments change produces different implications for incumbents, mutuals, challengers, universal banks and infrastructure participants.

| Field | Value |
|---|---|
| Observation type | Structural |
| Affected participant | All participants |
| Evidence | BANK-TWIN-001; BANK-MECH-001; BANK-OBS-001 |
| Supporting governed observations | BK-OBS-002; BK-OBS-004; BK-OBS-014; BK-OBS-042 |
| Related mechanisms | BM-04; BM-16; BM-19; BM-20; BM-22 |
| Related hypotheses | BRH-003; BRH-007; BRH-008; BRH-010 |
| Confidence | High |
| Unknowns | Quantified commercial exposure remains unavailable without account and procurement evidence. |
| Contradictions | None unresolved in this observation unless listed in `13-Contradiction-Register.md` |
| Freshness | Current to governed source cut-off; refresh on new participant evidence |
| Lineage | Evidence -> governed observation -> mechanism -> participant intelligence |
