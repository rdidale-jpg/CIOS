# Research Limitations

**Asset ID:** `EK-BANK-MPI-001-LIM`  
**Effective date:** 2026-07-19

## Global limitations

1. No new external research was performed; this release uses only governed Banking assets supplied in the workspace.
2. Full Market Participant Twins were created by reference, not by rebuilding Enterprise Twins.
3. Technology/platform participant coverage is cohort-level because bank-by-bank cloud/AI workload exposure is not available.
4. No individual executives are named.
5. No account relationship intelligence, procurement-route knowledge or private commercial context was supplied.
6. No automated scoring, ranking or prioritisation model is created.
7. Whitespace propositions are candidate interpretations, not recommendations.
8. Competitor moves are supported by governed assets but may not capture current events after the source cut-off.
9. Pay.UK/infrastructure is used as the initial infrastructure participant, while other shared-access actors remain future extension candidates.
10. HSBC UK, Chase UK, Atom, Metro, Cash Access UK, Post Office and individual hyperscalers are not fully modelled in this release.

## Limitations by analysis area

| Area | Limitation | Consequence |
|---|---|---|
| Participant economics | Public source Twins do not expose all product-level profitability, cohort economics or channel costs. | Do not use this asset to make numeric exposure rankings. |
| Executive ownership | Role-level analysis only. | Do not infer named sponsorship. |
| Programme state | Active programme details are uneven across participants. | Use Unknown Register before account action. |
| Supplier landscape | Exact supplier workshare and contract expiry are incomplete. | Do not infer accessibility or incumbent displacement. |
| Technology exposure | Cloud/core workload maps and exit plans remain unknown. | Treat technology/provider conclusions as dependency signals, not account facts. |
| Competitor pressure | Relationships are contextual, not whole-company competitive maps. | Do not auto-generate generic `competes_with` edges. |
| Opportunity implication | Relevance is qualitative and evidence-bounded. | Do not convert relevance into sales priority without commercial qualification. |

## Recommended next research increment

Wave A should deepen four high-contrast participant cases: Lloyds, Nationwide/Virgin Money, Monzo and Pay.UK/infrastructure. It should collect current evidence for access strategy, payment dependency, customer outcomes, programme ownership, supplier workshare and executive decision rights.
