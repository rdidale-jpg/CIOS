# Pull Request Draft

**Title:** Build governed Banking market participant intelligence

## Summary

This PR creates the first governed Banking Market Participant Intelligence asset. It allows Flora and future Codex implementation to compare major UK Banking participants, interpret competitor moves and preserve participant-specific opportunity implications without inventing missing knowledge.

## Repository path

`enterprise-knowledge/banking/market-participant/`

## What changed

- Added repository reconnaissance report.
- Added initial participant cohort and coverage assessment.
- Added governed Market Participant Twins by reference for nine participants.
- Added candidate participant observations.
- Added competitor move records.
- Added competitive relationship records.
- Added participant comparison matrix.
- Added opportunity-to-participant analysis.
- Added strategic whitespace propositions.
- Added executive-role analysis.
- Added Unknown and Contradiction registers.
- Added evidence source register and limitations.
- Added Codex implementation handoff.
- Added validation and completion reports.

## Governance notes

- No production code.
- No UI.
- No automated ranking or scoring.
- No opportunity cards.
- No CRM integration.
- No recommendations.
- No unsupported participant ranking.
- No private human-supplied account knowledge used.

## Acceptance checks

- [x] At least four high-contrast participants have meaningful governed coverage.
- [x] Full initial cohort has explicit coverage assessment.
- [x] Participant Twins are comparable without becoming generic profiles.
- [x] Participant type materially affects opportunity interpretation.
- [x] Competitor moves are evidence-backed.
- [x] Competitive relationships are contextual.
- [x] Existing Banking opportunities have participant-specific implications.
- [x] Unknowns and Contradictions are explicit.
- [x] Evidence freshness is visible.
- [x] Codex handoff separates safe fields from fields requiring research.
- [x] Validation report created.

## Review focus

1. Should the cloud/AI participant remain a cohort or be split into individual provider participant records?
2. Should Cash Access UK/Post Office/LINK become standalone shared-access participants in the next increment?
3. Which candidate participant observations should be promoted into the canonical Banking Observation Register?
4. Which whitespace propositions should become Opportunity Candidate records after account/procurement evidence is added?
