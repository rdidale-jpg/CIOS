# TEL-001 Wave 5 Research Method

Wave 5 used the Wave 4 checkpoint as authoritative state and did not rebuild the Twin.

Method:
1. Reviewed all 17 Wave 4 Opportunity Objects.
2. Applied Wave 5 commercial opportunity taxonomy.
3. Applied value taxonomy and removed framework ceilings from named pipeline totals.
4. Reviewed existing awards and created residual-opportunity treatment.
5. Applied procurement maturity and timing-confidence gates.
6. Created qualified pipeline totals and overlap controls.
7. Preserved Unknowns beneath estimates.
8. Added field-specific evidence and monitoring triggers.

Primary evidence used includes official procurement notices, GCA framework pages, BDUK contract pages, CMA case pages, Ofcom reports/consultations and official company announcements.

Limitations:
- No employer-specific supplier suitability was inferred.
- No private operator procurement was treated as fact.
- No framework ceiling was treated as sales forecast.
