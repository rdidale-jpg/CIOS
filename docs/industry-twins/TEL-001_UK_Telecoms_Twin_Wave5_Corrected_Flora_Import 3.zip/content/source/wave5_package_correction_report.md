# TEL-001 Wave 5 Package Correction Report

## Outcome

CORRECTED

## Correction date

2026-08-03

## Scope

Corrected customer and business-unit identity resolution across the Wave 5 package.

No further broad research was performed.

## Correction boundary

The correction did not change:

- commercial type;
- Horizon;
- procurement status;
- timing;
- value;
- confidence;
- estimates;
- Unknowns;
- Contradictions;
- framework treatment;
- existing-award treatment.

## Resolution rules applied

Customer identity was resolved from:

1. explicit customer reference on the Opportunity Object;
2. typed Opportunity-targets-Enterprise relationship;
3. explicit linked Programme owner where valid and non-conflicting;
4. explicit multi-buyer framework context;
5. otherwise Customer unresolved.

Business-unit identity was resolved from:

1. explicit business-unit reference on the Opportunity Object, including structured affected_business_unit fields;
2. typed Opportunity-targets-Business-Unit relationship;
3. linked Programme business-unit owner where valid;
4. otherwise Business unit unresolved.

No identity was resolved from opportunity title, free-text narrative, supplier name, evidence publisher or keyword similarity.

## Reviewed opportunities

17 Opportunity Objects reviewed.

## Corrected Opportunity IDs

- OPP-VT-NETWORK-AI-OPS
- OPP-VT-ENTERPRISE-5G
- OPP-CITYFIBRE-PROJECT-GIGABIT
- OPP-CITYFIBRE-WHOLESALE
- OPP-TALKTALK-COST
- OPP-PXC-PLATFORM-EFFICIENCY
- OPP-OPENREACH-BDUK-DELIVERY-ASSURANCE
- OPP-VMO2-MOBILE-RAN-AI-ASSURANCE
- OPP-VMO2-NEXFIBRE-MIGRATION
- OPP-VT-WHOLESALE-REMEDY-ASSURANCE
- OPP-GOV-NS4-TELCO-PUBLIC-SECTOR
- OPP-BT-VERIZON-JV-INTEGRATION

## Unresolved customer identities

None.

## Unresolved business units

- OPP-GOV-NS4-TELCO-PUBLIC-SECTOR: Business unit unresolved — multi-buyer call-off business units not yet identified

## Specific checks

| Check | Result |
|---|---|
| VodafoneThree network integration | Corrected to VodafoneThree / Network/integration |
| VodafoneThree private 5G | Corrected to VodafoneThree / Business/enterprise 5G |
| CityFibre wholesale | Corrected to CityFibre / Wholesale platform and network operations |
| TalkTalk | Corrected to TalkTalk / TalkTalk Consumer and group operations |
| PXC | Corrected to TalkTalk / PlatformX Communications wholesale and B2B |
| VMO2 / nexfibre migration | Corrected to Virgin Media O2 / Consumer fixed and wholesale infrastructure |
| VodafoneThree wholesale-reference-offer compliance | Corrected to VodafoneThree / Wholesale, regulatory and network operations |
| Network Services 4 | Corrected to multi-buyer framework market with framework owner and buyer population separated |
| BT–Verizon integration | Corrected to BT Group / BT International and proposed JV |
| Sole named H1 open opportunity | Corrected; VodafoneThree customer and business unit are no longer blank |

## Regenerated outputs

- Qualified Opportunity Register;
- corrected Horizon pipeline;
- Named Open Opportunity Pipeline;
- Shaping Opportunity Register;
- Strategic Hypothesis Register;
- Existing Award Register;
- Residual Opportunity Register;
- Framework Market Register;
- Buyer Intelligence Register;
- Procurement Register;
- Opportunity Qualification Scorecard;
- Horizon Reclassification Report;
- executive pipeline summary;
- executive opportunity dossiers;
- value reconciliation report;
- identity-resolution table;
- CSV, JSON and Markdown projections where applicable.

## Release status

Release Manifest remains draft.

TEL-001 mission outcome remains CONTINUE.
