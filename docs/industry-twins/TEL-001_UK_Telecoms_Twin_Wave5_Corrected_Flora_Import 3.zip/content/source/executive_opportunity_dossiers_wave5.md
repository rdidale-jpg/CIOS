# TEL-001 Wave 5 Executive Opportunity Dossiers — Corrected

Correction date: 2026-08-03

Customer and business-unit identities in this projection are canonicalised from supported object fields, typed relationships, linked programmes or explicit framework context only.

## VMO2 customer operations AI expansion, governance and assurance

**Opportunity ID:** OPP-VMO2-AI-CX  
**Canonical customer:** Virgin Media O2  
**Canonical customer Twin ID:** ENT-VMO2  
**Canonical business unit:** Customer operations / Consumer  
**Canonical business-unit ID:** ENT-VMO2:BU-Customer-operations-Consumer  
**Commercial status:** Shaping opportunity / Estimated pipeline  
**Horizon:** Horizon 2  
**Procurement:** Pre-procurement signal / maturity: Programme mobilised / supplier-enabled AI tooling active; external follow-on procurement not evidenced  
**Timing:** Q3 2026–Q2 2027 (Low confidence)  
**Value:** Estimated contract-value range — £5.0m–£20.0m (Low confidence)  
**Buyer:** Likely — Chief Customer Officer / Customer Operations Director / CIO or Digital executive  
**Value treatment:** Named open/shaping opportunity  
**Recommended action:** Shape — Shape around governed AI operations, complaint-resolution controls, vulnerable-customer assurance and agent-workflow integration rather than generic AI tooling.  
**Falsification:** VMO2 confirms Lumi/AWS scope is fully internal or long-term sole-source with no partner extensions.; Customer operations programme is paused or budget withdrawn.; Complaint/customer-experience metrics improve sufficiently without additional external scope.  
**Next trigger:** VMO2 FY26/Q3-Q4 customer-service results, AWS/Google/Accenture customer operations case updates or any contact-centre/AI assurance tender.  
**Evidence:** EV-VMO2-Q2FY26-W4; EV-VMO2-LUMI-2025; EV-VMO2-LUMI; EV-W5-VMO2-AI-CX  
**Identity resolution:** Customer = Rule 1: explicit customer reference on Opportunity Object; Business unit = Rule 1: explicit business_unit on Opportunity Object.  

## BT AI-enabled engineering and field operations optimisation

**Opportunity ID:** OPP-BT-AI-ENGINEERING  
**Canonical customer:** BT Group  
**Canonical customer Twin ID:** ENT-BT  
**Canonical business unit:** BT Group transformation / Networks / Field engineering  
**Canonical business-unit ID:** ENT-BT:BU-BT-Group-transformation-Networks-Field-engineering  
**Commercial status:** Shaping opportunity / Estimated pipeline  
**Horizon:** Horizon 2  
**Procurement:** Pre-procurement signal / maturity: Funded transformation / target operating model forming  
**Timing:** Q1 2027–Q4 2028 (Low confidence)  
**Value:** Estimated contract-value range — £10.0m–£50.0m (Low confidence)  
**Buyer:** Likely — Chief Digital/Technology leadership and BT Sourced procurement  
**Value treatment:** Named open/shaping opportunity  
**Recommended action:** Shape — Shape with cost-to-serve, field-productivity and governed AI operations proposition; seek BT Sourced route intelligence.  
**Falsification:** BT confirms AI engineering platform is standardised on existing suppliers with no external expansion.; Cost-transformation scope deprioritises engineering automation.; Procurement is delivered entirely via internal teams or existing licences.  
**Next trigger:** BT FY27 trading updates, BT Sourced notices, engineering-platform or field-operations supplier announcements.  
**Evidence:** EV-BT-AR26; EV-BT-Q1FY27-W4; EV-BT-KYNDRYL; EV-BT-DYNATRACE  
**Identity resolution:** Customer = Rule 1: explicit customer reference on Opportunity Object; Business unit = Rule 1: explicit business_unit on Opportunity Object.  

## Openreach CP fibre activation and copper migration enablement

**Opportunity ID:** OPP-OPENREACH-CP-ENABLEMENT  
**Canonical customer:** Openreach  
**Canonical customer Twin ID:** ENT-OPENREACH  
**Canonical business unit:** Wholesale access / CP enablement  
**Canonical business-unit ID:** ENT-OPENREACH:BU-Wholesale-access-CP-enablement  
**Commercial status:** Shaping opportunity / Estimated pipeline  
**Horizon:** Horizon 2  
**Procurement:** Procurement expected / maturity: Programme announced / delivery pressure / regulatory-commercial environment changing  
**Timing:** Q1 2027–Q4 2028 (Low confidence)  
**Value:** Estimated contract-value range — £15.0m–£60.0m (Low confidence)  
**Buyer:** Likely — Openreach wholesale/customer migration leadership  
**Value treatment:** Named open/shaping opportunity  
**Recommended action:** Shape — Shape around CP onboarding, migration analytics, service assurance and regulated-wholesale compliance.  
**Falsification:** Openreach migrates using only internal tooling.; Regulatory/copper deadlines move materially later.; Wholesale CP migration proves lower-friction than expected.  
**Next trigger:** Ofcom final decision on Openreach commercial offers, CP migration notices, Openreach process/API changes.  
**Evidence:** EV-OF-CMR26-W4; EV-OF-CNS-SPRING26; EV-OF-TAR26; EV-W5-OF-OPENREACH-OFFERS  
**Identity resolution:** Customer = Rule 1: explicit customer reference on Opportunity Object; Business unit = Rule 1: explicit business_unit on Opportunity Object.  

## VodafoneThree network integration assurance and AI operations

**Opportunity ID:** OPP-VT-NETWORK-AI-OPS  
**Canonical customer:** VodafoneThree  
**Canonical customer Twin ID:** ENT-VODAFONETHREE  
**Canonical business unit:** Network/integration  
**Canonical business-unit ID:** ENT-VODAFONETHREE:BU-Network-integration  
**Commercial status:** Shaping opportunity / Estimated pipeline  
**Horizon:** Horizon 2  
**Procurement:** Pre-procurement signal / maturity: Programme mobilised / delivery / architecture integration  
**Timing:** Q4 2026–Q4 2027 (Low confidence)  
**Value:** Estimated externally addressable scope — £30.0m–£120.0m (Low confidence)  
**Buyer:** Likely — CTO/network integration leadership / Vodafone Group technology leadership  
**Value treatment:** Named open/shaping opportunity with incumbent-overlap risk  
**Recommended action:** Shape — Shape around integration assurance, multi-vendor observability, cyber/resilience and benefits-realisation controls; do not pitch replacement of incumbent RAN/core vendors without evidence.  
**Falsification:** Integration fully covered by incumbent Ericsson/Nokia contracts.; VodafoneThree shifts scope to internal delivery.; Regulatory or technical constraints delay integration beyond assessed horizon.  
**Next trigger:** VodafoneThree integration operating model update, supplier announcements, network-performance reporting or procurement notices.  
**Evidence:** EV-VT-OWNERSHIP-W4; EV-ERICSSON-VT-MOCN-W4; EV-VT-5GSA26; EV-W5-VODAFONE-OWNERSHIP; EV-W5-VODAFONETHREE-MOCN  
**Identity resolution:** Customer = Rule 2: typed Opportunity-targets-Enterprise relationship; Business unit = Rule 1: explicit affected_business_unit on Opportunity Object.  

## CityFibre wholesale platform scaling and partner assurance

**Opportunity ID:** OPP-CITYFIBRE-WHOLESALE  
**Canonical customer:** CityFibre  
**Canonical customer Twin ID:** ENT-CITYFIBRE  
**Canonical business unit:** Wholesale platform / network operations  
**Canonical business-unit ID:** ENT-CITYFIBRE:BU-Wholesale-platform-network-operations  
**Commercial status:** Shaping opportunity / Estimated pipeline  
**Horizon:** Horizon 2  
**Procurement:** Pre-procurement signal / maturity: Strategic commitment / platform scaling  
**Timing:** Q1 2027–Q4 2028 (Low confidence)  
**Value:** Estimated contract-value range — £5.0m–£30.0m (Low confidence)  
**Buyer:** Likely — CityFibre wholesale/platform leadership  
**Value treatment:** Named open/shaping opportunity  
**Recommended action:** Shape — Shape around wholesale onboarding, CP experience, network analytics and BDUK delivery controls.  
**Falsification:** CityFibre delays consolidation or funding does not complete.; Wholesale platform is already fully insourced.; ISP partner growth slows materially.  
**Next trigger:** CityFibre wholesale partner wins, platform/service-assurance announcements, procurement notices, debt/refinancing updates.  
**Evidence:** EV-CITYFIBRE-FY25-W4; EV-CITYFIBRE-1M-W4; EV-REUTERS-CITYFIBRE-900M-W4  
**Identity resolution:** Customer = Rule 2: typed Opportunity-targets-Enterprise relationship; Business unit = Rule 1: explicit affected_business_unit on Opportunity Object.  

## VMO2/nexfibre/Netomnia fibre migration and wholesale integration

**Opportunity ID:** OPP-VMO2-NEXFIBRE-MIGRATION  
**Canonical customer:** Virgin Media O2  
**Canonical customer Twin ID:** ENT-VMO2  
**Canonical business unit:** Consumer fixed / wholesale infrastructure  
**Canonical business-unit ID:** ENT-VMO2:BU-Consumer-fixed-wholesale-infrastructure  
**Commercial status:** Shaping opportunity / Estimated pipeline  
**Horizon:** Horizon 2  
**Procurement:** Strategic formation / maturity: Strategic formation / regulatory review  
**Timing:** Q1 2027–Q4 2028 if CMA clearance permits (Low confidence)  
**Value:** Estimated contingent contract-value range — £20.0m–£80.0m (Low confidence)  
**Buyer:** Likely — VMO2 fixed/consumer leadership and nexfibre leadership  
**Value treatment:** Named shaping opportunity; contingent on CMA outcome  
**Recommended action:** Shape — Shape only through scenario planning and ecosystem positioning; do not treat as active pursuit until CMA outcome and integration owner are known.  
**Falsification:** CMA blocks or imposes remedies that prevent assumed integration.; Transaction delayed beyond 2028.; Integration performed internally or by incumbent suppliers only.  
**Next trigger:** CMA Phase 2 provisional findings, remedies, final decision or transaction abandonment before 15 December 2026.  
**Evidence:** EV-NEXFIBRE-SUBSTANTIAL26; EV-CMA-NEXFIBRE-IU-W4; EV-BT-CMA-NEXFIBRE-RESPONSE26; EV-W5-CMA-NEXFIBRE-SUBSTANTIAL  
**Identity resolution:** Customer = Rule 2: typed Opportunity-targets-Enterprise relationship; Business unit = Rule 1: explicit affected_business_unit on Opportunity Object.  

## VodafoneThree wholesale-reference-offer compliance and assurance

**Opportunity ID:** OPP-VT-WHOLESALE-REMEDY-ASSURANCE  
**Canonical customer:** VodafoneThree  
**Canonical customer Twin ID:** ENT-VODAFONETHREE  
**Canonical business unit:** Wholesale / regulatory / network operations  
**Canonical business-unit ID:** ENT-VODAFONETHREE:BU-Wholesale-regulatory-network-operations  
**Commercial status:** Open opportunity / Estimated pipeline  
**Horizon:** Horizon 1  
**Procurement:** Pre-procurement signal / maturity: Regulatory obligation / remedy monitoring  
**Timing:** Q4 2026–Q3 2027 (Medium-Low confidence)  
**Value:** Estimated contract-value range — £5.0m–£20.0m (Low confidence)  
**Buyer:** Likely — Regulatory affairs / wholesale leadership  
**Value treatment:** Named open opportunity  
**Recommended action:** Pursue now — Pursue qualification with regulatory, wholesale and compliance stakeholders; position independent assurance, data/reporting controls and wholesale-service transparency.  
**Falsification:** VodafoneThree handles compliance entirely internally.; Remedy scope narrows materially.; Regulators require no additional reporting beyond existing processes.  
**Next trigger:** VodafoneThree WRO/compliance reporting cycle, Ofcom/CMA remedy updates, wholesale offer publication or assurance partner disclosure.  
**Evidence:** EV-CMA-VT-CLOSE25; EV-VT-WRO26; EV-VT-OWNERSHIP-W4; EV-W5-VODAFONE-OWNERSHIP  
**Identity resolution:** Customer = Rule 2: typed Opportunity-targets-Enterprise relationship; Business unit = Rule 1: explicit affected_business_unit on Opportunity Object.  

## UK public-sector telecoms via Network Services 4

**Opportunity ID:** OPP-GOV-NS4-TELCO-PUBLIC-SECTOR  
**Canonical customer:** Multi-buyer UK public-sector framework market  
**Canonical customer Twin ID:** MULTI-BUYER-FRAMEWORK-NS4  
**Canonical business unit:** Business unit unresolved — multi-buyer call-off business units not yet identified  
**Canonical business-unit ID:** BUSINESS_UNIT_UNRESOLVED_MULTI_BUYER_NS4  
**Framework owner:** Crown Commercial Service / Government Commercial Function (MP-CCS-GCA)  
**Buyer population:** UK public-sector buyers using Network Services 4 call-offs; named call-off customers unresolved until awards/call-offs are published  
**Commercial status:** Framework market / Framework market  
**Horizon:** Horizon 1  
**Procurement:** Formal market engagement / maturity: Formal market engagement / procurement documentation drafting  
**Timing:** August 2026 ITT; framework award February 2027 (High confidence)  
**Value:** Framework ceiling — £7000.0m–£8400.0m (High for ceiling; Low for supplier share confidence)  
**Buyer:** Known — Government Commercial Agency commercial/category leadership  
**Value treatment:** Framework market ceiling; report separately from named pipeline  
**Recommended action:** Pursue framework route, not named opportunity — Mobilise framework bid/readiness activity; do not aggregate the ceiling into account pipeline.  
**Falsification:** GCA delays ITT beyond 12 months.; Final scope excludes target services.; Supplier fails qualification or chooses not to bid.; Framework value changes materially in final notice.  
**Next trigger:** GCA/Find a Tender contract notice for RM6377, supplier list, final lot structure, framework award and named call-offs.  
**Evidence:** EV-GCA-NS4-RM6377-W4; EV-FTS-NS4-PME-W4; EV-W5-GCA-NS4; EV-W5-FTS-NS4-PIPELINE  
**Identity resolution:** Customer = Rule 4: explicit multi-buyer framework context; Business unit = Framework handling: buyer population known; individual call-off business units unresolved.  

## BT-Verizon international enterprise JV integration and AI-ready platform assurance

**Opportunity ID:** OPP-BT-VERIZON-JV-INTEGRATION  
**Canonical customer:** BT Group  
**Canonical customer Twin ID:** ENT-BT  
**Canonical business unit:** BT International / proposed JV  
**Canonical business-unit ID:** ENT-BT:BU-BT-International-proposed-JV  
**Commercial status:** Shaping opportunity / Estimated pipeline  
**Horizon:** Horizon 2  
**Procurement:** Pre-procurement signal / maturity: Strategic commitment / operating model forming  
**Timing:** Q4 2026–Q4 2027 (Low confidence)  
**Value:** Estimated contract-value range — £20.0m–£80.0m (Low confidence)  
**Buyer:** Likely — BT International CEO / JV CEO-designate / Verizon international leadership  
**Value treatment:** Named open/shaping opportunity  
**Recommended action:** Shape — Shape around enterprise-service continuity, platform integration risk and AI-ready operating model; wait for buyer/route evidence before pursuit classification.  
**Falsification:** Regulatory clearances fail or completion moves beyond 2027.; JV insources integration or uses parent-company incumbents exclusively.; Scope narrowed to legal/account transfer with minimal platform work.  
**Next trigger:** BT-Verizon JV governance update, platform architecture disclosure, customer migration milestone or procurement notice.  
**Evidence:** EV-BT-VERIZON-JV-W4  
**Identity resolution:** Customer = Rule 2: typed Opportunity-targets-Enterprise relationship; Business unit = Rule 1: explicit affected_business_unit on Opportunity Object.  

