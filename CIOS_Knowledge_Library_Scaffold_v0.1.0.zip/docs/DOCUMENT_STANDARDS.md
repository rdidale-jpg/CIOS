# CIOS Document Standards

## Naming Convention

Use:

`CIOS-<STREAM>-<NUMBER>_<Short_Title>_v<MAJOR>.<MINOR>.<PATCH>.<ext>`

Examples:

- `CIOS-CON-001_CIOS_Constitution_v1.1.0.md`
- `CIOS-SCI-001_Foundations_of_Commercial_Cognitive_Science_v0.1.0.md`
- `CIOS-ENG-005_Provider_Abstraction_Standard_v0.1.0.md`

## Streams

| Prefix | Meaning |
|---|---|
| CON | Constitution |
| SCI | Commercial Science |
| ENG | Engineering |
| PMO | Programme |
| MOD | Models |
| RES | Research |
| APP | Applications |

## Versioning

Use semantic versioning:

- `0.x` — draft / experimental
- `1.0` — first approved baseline
- `1.x` — compatible refinements
- `2.0` — major restructuring or changed meaning

## Document Header

Each document should include:

- Document ID
- Title
- Version
- Status
- Owner
- Last Updated
- Related Artefacts
- Location
