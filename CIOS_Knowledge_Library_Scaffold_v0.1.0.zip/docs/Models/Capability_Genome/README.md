# Capability Genome

Purpose: store CIOS artefacts for this knowledge area.
