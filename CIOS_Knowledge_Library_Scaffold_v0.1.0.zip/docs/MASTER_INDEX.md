# CIOS Master Knowledge Index

| ID | Title | Type | Status | Version | Location |
|---|---|---|---|---|---|
| CIOS-CON-001 | CIOS Constitution | Constitution | Draft | v1.1 | docs/Constitution/ |
| CIOS-SCI-001 | Foundations of Commercial Cognitive Science | Science | Draft Alpha | v0.1 | docs/Science/ |
| CIOS-ENG-001 | SDK Specification | Engineering | Approved | v1.0 | docs/Engineering/ |
| CIOS-ENG-002 | Platform Architecture & Dependency Model | Engineering | Approved | v1.0 | docs/Engineering/ |
| CIOS-ENG-003 | Commercial Intelligence Pipeline Specification | Engineering | Approved | v1.0 | docs/Engineering/ |
| CIOS-ENG-004 | Application Composition Standard | Engineering | Draft | v0.1 | docs/Engineering/ |

## Status Values

- Draft
- Review
- Approved
- Implemented
- Superseded
- Archived
