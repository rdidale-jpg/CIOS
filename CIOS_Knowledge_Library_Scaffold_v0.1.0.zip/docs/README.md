# CIOS Knowledge Library

This directory contains the intellectual property, scientific canon, engineering standards, research artefacts, models and diagrams that support CIOS.

## Structure

- `Constitution/` — foundational constitutional documents.
- `Science/` — Commercial Cognitive Science, Commercial Physics, Influence Science and related scientific foundations.
- `Engineering/` — engineering standards and architecture specifications.
- `Research/` — supporting research, literature reviews and validation material.
- `Models/` — Enterprise Genome, Capability Genome, Commercial Rules and Influence Models.
- `Images/` — diagrams and visual assets.

## Canonical Format

Markdown (`.md`) should be treated as the canonical version-controlled source.

Word (`.docx`) versions may be used as polished review/distribution copies.
