# CIOS Knowledge Traceability

This file tracks relationships between constitutional principles, commercial science, engineering standards, code modules and applications.

| Source Artefact | Principle / Concept | Engineering Artefact | Code Area | Application |
|---|---|---|---|---|
| CIOS-CON-001 | Evidence before opinion | ENG-003 Pipeline Specification | cios.core, cios.reasoning | Opportunity Assistant |
| CIOS-CON-001 | Explainability before automation | ENG-004 Application Composition Standard | explainability.py | Opportunity Assistant |
| CIOS-SCI-001 | Commercial Physics | Future ENG standards | scoring, reasoning | Opportunity Assistant |
