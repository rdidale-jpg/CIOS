# README — TMS-001 Final Governed Package

## Authoritative state
`TMS-001_Final_Workspace.json` is the authoritative consolidated research-state container. Numbered JSON files are modular machine-inspectable views.

## Restart
1. Validate `00_manifest.json` checksums.
2. Load `TMS-001_Final_Workspace.json`.
3. Treat CP-002 as the accepted restart state and CP-FINAL as final research checkpoint.
4. Process monitoring triggers rather than recreating the baseline.

## Status boundary
Research-ready with Conditions. Not Accepted, not Canonical, not Architecture-ready, not Implementation-ready, not Pilot-ready.

## File index
01 final Industry Twin; 02 Enterprise Twins; 03 Market Participants; 04 Opportunities; 05 Control Bodies; 06 Value Chains; 07 Economics/Investment; 08 Procurement/Commercial Routes; 09 Transformations; 10 Cross-domain Dependencies; 11 Executive Intelligence; 12 Ranked Opportunities; 13 AI Assessment; 14 Maturity; 15 Decision Completeness; 16 Unknowns; 17 Contradictions; 18 Evidence Register; 19 Queue Disposition; 20 Restart State; 21 Flora Delta; 22 README/Summary; consolidated Workspace.
