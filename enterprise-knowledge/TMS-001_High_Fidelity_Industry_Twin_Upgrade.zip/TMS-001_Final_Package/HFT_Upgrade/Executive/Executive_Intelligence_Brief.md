# TMS-001 Executive Intelligence Brief

**Release:** TMS-001-HFT-UPGRADE-2026-07-26  
**Effective date:** 2026-07-26  
**Status:** Research-ready with conditions. Not Accepted, Architecture-ready, Implementation-ready or Promotion-ready.

## Executive view

The upgraded Industry Twin indicates that UK Telecommunications, Media and Sport is best understood as three interconnected commercial systems rather than three disconnected verticals. Connectivity infrastructure, platform media economics and sport rights/data/fan relationships increasingly depend on common capabilities: cloud, AI, measurement, regulatory compliance, security assurance, data rights and audience/fan engagement.

## What is changing

### Telecommunications

Coverage build remains important, but it is no longer sufficient as the main commercial signal. Ofcom evidence shows high full-fibre and gigabit coverage with take-up still materially below availability. Current operator evidence adds named 5G SA, fibre, security and supplier investment signals.

**Commercial implication:** executive attention should move from “who is building network” to “who can monetise, secure, migrate and differentiate the network.”

### Media

Media structure is being reshaped by linear decline, streaming/BVOD growth, platform discovery and live consolidation uncertainty. The CMA Sky/ITV M&E case remains open at invitation-to-comment stage, so the Twin preserves Sky and ITV as separate scenario objects.

**Commercial implication:** the attractive capability zone is BVOD/adtech, cloud production/distribution, cross-platform measurement, PSM prominence and regulatory/platform compliance.

### Sport

Sport is moving beyond broadcast-rights economics into a combined rights, official data, AI fan product and governance environment. The Football Governance Act and IFR introduce a new regulatory layer, while the Premier League’s rights, Genius official-data exclusivity and Microsoft partnership expose new commercial control points.

**Commercial implication:** sport opportunities should be framed around official data, AI fan engagement, rights protection, compliance and public outcomes rather than generic digital engagement.

## Strategic signals

|Signal|Title|Confidence|
|---|---|---|
|SIG-TEL-001|Telecoms monetisation and assurance shift|High|
|SIG-MED-001|Platform-era media reconfiguration|High|
|SIG-SPORT-001|Sport governance/data/fan product convergence|High|
|SIG-SUP-001|Supplier ecosystem entanglement|High|

## Evidence-bounded recommendations

|Recommendation|Title|Confidence|Smallest evidence-led next step|
|---|---|---|---|
|REC-001|Prioritise three account pods|Medium-High|Validate 10 named buyer buying centres through procurement notices, annual reports and partner case evidence.|
|REC-002|Run a procurement and contract evidence wave|High|Search procurement portals, company RNS/press, framework awards and regulator consultations for each priority object.|
|REC-003|Treat Sky/ITV as a scenario trigger, not a settled structure|High|Set a watch rule for CMA milestone updates and affected capability/buyer remapping.|
|REC-004|Use official data and AI fan partnership as sport control points|Medium-High|Map PL/EFL/FDC/Genius/Microsoft object relationships into club-level and broadcaster-level buying centres.|

## Executive cautions

- Do not treat VodafoneThree supplier announcements as proof of enterprise 5G SA monetisation.
- Do not treat digital growth as fully replacing linear broadcaster economics.
- Do not treat Premier League revenue growth as economic health without cost/profitability evidence.
- Do not treat Sky/ITV as a completed market structure while the CMA process remains unresolved.
- Do not use metadata-only analyst sources for detailed numerical claims.

## Recommended next research wave

Run a procurement and contract evidence wave covering telecoms security/5G SA, broadcaster cloud/BVOD/measurement/prominence, and sport official-data/fan-product/governance buying centres.
